package com.example.weight_trackingapp

import com.example.weight_trackingapp.util.SecurityUtils
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for SecurityUtils.
 *
 * Tests password hashing, validation, and input sanitization.
 */
class SecurityUtilsTest {

    // ==================== PASSWORD HASHING TESTS ====================

    @Test
    fun hashPassword_returnsNonEmptyHash() {
        val password = "TestPassword123"
        val hash = SecurityUtils.hashPassword(password)

        assertNotNull(hash)
        assertTrue(hash.isNotEmpty())
        assertNotEquals(password, hash)
    }

    @Test
    fun hashPassword_differentPasswordsProduceDifferentHashes() {
        val hash1 = SecurityUtils.hashPassword("Password123")
        val hash2 = SecurityUtils.hashPassword("Password456")

        assertNotEquals(hash1, hash2)
    }

    @Test
    fun verifyPassword_correctPasswordReturnsTrue() {
        val password = "TestPassword123"
        val hash = SecurityUtils.hashPassword(password)

        assertTrue(SecurityUtils.verifyPassword(password, hash))
    }

    @Test
    fun verifyPassword_wrongPasswordReturnsFalse() {
        val password = "TestPassword123"
        val wrongPassword = "WrongPassword123"
        val hash = SecurityUtils.hashPassword(password)

        assertFalse(SecurityUtils.verifyPassword(wrongPassword, hash))
    }

    // ==================== PASSWORD VALIDATION TESTS ====================

    @Test
    fun validatePassword_validPasswordReturnsTrue() {
        val result = SecurityUtils.validatePassword("ValidPass1")

        assertTrue(result.isValid)
        assertTrue(result.errorMessage.isEmpty())
    }

    @Test
    fun validatePassword_tooShortReturnsFalse() {
        val result = SecurityUtils.validatePassword("Short1")

        assertFalse(result.isValid)
        assertTrue(result.errorMessage.contains("8 characters"))
    }

    @Test
    fun validatePassword_noUppercaseReturnsFalse() {
        val result = SecurityUtils.validatePassword("lowercase123")

        assertFalse(result.isValid)
        assertTrue(result.errorMessage.contains("uppercase"))
    }

    @Test
    fun validatePassword_noLowercaseReturnsFalse() {
        val result = SecurityUtils.validatePassword("UPPERCASE123")

        assertFalse(result.isValid)
        assertTrue(result.errorMessage.contains("lowercase"))
    }

    @Test
    fun validatePassword_noNumberReturnsFalse() {
        val result = SecurityUtils.validatePassword("NoNumbersHere")

        assertFalse(result.isValid)
        assertTrue(result.errorMessage.contains("number"))
    }

    // ==================== USERNAME VALIDATION TESTS ====================

    @Test
    fun validateUsername_validUsernameReturnsTrue() {
        val result = SecurityUtils.validateUsername("validUser123")

        assertTrue(result.isValid)
    }

    @Test
    fun validateUsername_tooShortReturnsFalse() {
        val result = SecurityUtils.validateUsername("ab")

        assertFalse(result.isValid)
        assertTrue(result.errorMessage.contains("3 characters"))
    }

    @Test
    fun validateUsername_startsWithNumberReturnsFalse() {
        val result = SecurityUtils.validateUsername("123user")

        assertFalse(result.isValid)
        assertTrue(result.errorMessage.contains("start with a letter"))
    }

    // ==================== INPUT SANITIZATION TESTS ====================

    @Test
    fun sanitizeInput_trimsWhitespace() {
        val input = "  hello world  "
        val sanitized = SecurityUtils.sanitizeInput(input)

        assertEquals("hello world", sanitized)
    }

    @Test
    fun sanitizeInput_limitsLength() {
        val longInput = "a".repeat(2000)
        val sanitized = SecurityUtils.sanitizeInput(longInput)

        assertEquals(1000, sanitized.length)
    }
}