package com.example.weight_trackingapp

import com.example.weight_trackingapp.algorithms.WeightStatistics
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for WeightStatistics algorithms.
 *
 * Tests:
 * - Moving Average Algorithm - O(n)
 * - Linear Regression Algorithm - O(n)
 * - Binary Search Algorithm - O(log n)
 * - Statistical Calculations
 */
class WeightStatisticsTest {

    // ==================== HELPER FUNCTION ====================

    private fun createTestEntries(weights: List<Double>): List<WeightEntry> {
        return weights.mapIndexed { index, weight ->
            WeightEntry(
                entryId = index + 1,
                userId = 1,
                weight = weight,
                timestamp = System.currentTimeMillis() + (index * 86400000L) // 1 day apart
            )
        }
    }

    // ==================== MOVING AVERAGE TESTS ====================

    @Test
    fun movingAverage_emptyListReturnsEmpty() {
        val entries = emptyList<WeightEntry>()
        val result = WeightStatistics.calculateMovingAverage(entries)
        assertTrue(result.isEmpty())
    }

    @Test
    fun movingAverage_lessThanWindowReturnsAverage() {
        val entries = createTestEntries(listOf(200.0, 198.0, 196.0))
        val result = WeightStatistics.calculateMovingAverage(entries, windowSize = 7)

        assertEquals(1, result.size)
        assertEquals(198.0, result[0], 0.01) // Average of 200, 198, 196
    }

    @Test
    fun movingAverage_correctCalculation() {
        val entries = createTestEntries(listOf(200.0, 199.0, 198.0, 197.0, 196.0, 195.0, 194.0))
        val result = WeightStatistics.calculateMovingAverage(entries, windowSize = 7)

        assertEquals(1, result.size)
        // Weighted average with weights [1,2,3,4,5,6,7]
        // (200*1 + 199*2 + 198*3 + 197*4 + 196*5 + 195*6 + 194*7) / 28
        assertTrue(result[0] < 197.0) // Should be weighted toward recent (lower) values
    }

    @Test
    fun simpleMovingAverage_correctCalculation() {
        val entries = createTestEntries(listOf(200.0, 198.0, 196.0, 194.0, 192.0, 190.0, 188.0))
        val result = WeightStatistics.calculateSimpleMovingAverage(entries, windowSize = 7)

        assertEquals(1, result.size)
        assertEquals(194.0, result[0], 0.01) // Simple average of all 7 values
    }

    // ==================== LINEAR REGRESSION TESTS ====================

    @Test
    fun linearRegression_insufficientDataReturnsNull() {
        val entries = createTestEntries(listOf(200.0))
        val result = WeightStatistics.calculateLinearRegression(entries)
        assertNull(result)
    }

    @Test
    fun linearRegression_perfectDownwardTrend() {
        // Perfect linear decrease: 200, 198, 196, 194, 192
        val entries = createTestEntries(listOf(200.0, 198.0, 196.0, 194.0, 192.0))
        val result = WeightStatistics.calculateLinearRegression(entries)

        assertNotNull(result)
        assertEquals(-2.0, result!!.slope, 0.01) // Losing 2 lbs per day
        assertEquals(200.0, result.intercept, 0.01) // Starting at 200
        assertEquals(1.0, result.rSquared, 0.01) // Perfect fit
    }

    @Test
    fun linearRegression_perfectUpwardTrend() {
        // Perfect linear increase: 180, 182, 184, 186, 188
        val entries = createTestEntries(listOf(180.0, 182.0, 184.0, 186.0, 188.0))
        val result = WeightStatistics.calculateLinearRegression(entries)

        assertNotNull(result)
        assertEquals(2.0, result!!.slope, 0.01) // Gaining 2 lbs per day
        assertEquals(180.0, result.intercept, 0.01) // Starting at 180
        assertEquals(1.0, result.rSquared, 0.01) // Perfect fit
    }

    @Test
    fun linearRegression_noTrend() {
        // Constant weight: 200, 200, 200, 200, 200
        val entries = createTestEntries(listOf(200.0, 200.0, 200.0, 200.0, 200.0))
        val result = WeightStatistics.calculateLinearRegression(entries)

        assertNotNull(result)
        assertEquals(0.0, result!!.slope, 0.01) // No change
    }

    // ==================== PREDICTION TESTS ====================

    @Test
    fun predictWeight_correctCalculation() {
        val regression = WeightStatistics.RegressionResult(
            slope = -0.5, // Losing 0.5 lbs per day
            intercept = 200.0,
            rSquared = 0.9
        )

        // After 10 days with 5 existing entries
        val predicted = WeightStatistics.predictWeight(regression, currentIndex = 5, daysFromNow = 10)

        // Day 15: 200 + (-0.5 * 15) = 200 - 7.5 = 192.5
        assertEquals(192.5, predicted, 0.01)
    }

    @Test
    fun estimateDaysToGoal_losingWeight() {
        val regression = WeightStatistics.RegressionResult(
            slope = -0.5, // Losing 0.5 lbs per day
            intercept = 200.0,
            rSquared = 0.9
        )

        // Currently at day 10 (weight = 200 - 0.5*10 = 195), goal is 180
        // Need to reach 180: 180 = -0.5 * day + 200
        // day = (200 - 180) / 0.5 = 40
        // Days from now = 40 - 10 = 30
        val days = WeightStatistics.estimateDaysToGoal(regression, currentIndex = 10, goalWeight = 180.0)

        assertEquals(30, days)
    }

    @Test
    fun estimateDaysToGoal_gainingWeightCantReachLowerGoal() {
        val regression = WeightStatistics.RegressionResult(
            slope = 0.5, // Gaining weight
            intercept = 200.0,
            rSquared = 0.9
        )

        // Gaining weight, can't reach lower goal
        val days = WeightStatistics.estimateDaysToGoal(regression, currentIndex = 10, goalWeight = 180.0)

        assertNull(days)
    }

    // ==================== BINARY SEARCH TESTS ====================

    @Test
    fun binarySearch_emptyListReturnsNegative() {
        val entries = emptyList<WeightEntry>()
        val result = WeightStatistics.binarySearchByDate(entries, System.currentTimeMillis())
        assertEquals(-1, result)
    }

    @Test
    fun binarySearch_findsExactMatch() {
        val baseTime = System.currentTimeMillis()
        val entries = (0..9).map { i ->
            WeightEntry(
                entryId = i + 1,
                userId = 1,
                weight = 200.0 - i,
                timestamp = baseTime + (i * 86400000L)
            )
        }

        val targetTime = baseTime + (5 * 86400000L) // Day 5
        val result = WeightStatistics.binarySearchByDate(entries, targetTime)

        assertEquals(5, result)
    }

    @Test
    fun binarySearch_notFoundReturnsNegative() {
        val baseTime = System.currentTimeMillis()
        val entries = (0..9).map { i ->
            WeightEntry(
                entryId = i + 1,
                userId = 1,
                weight = 200.0 - i,
                timestamp = baseTime + (i * 86400000L)
            )
        }

        val targetTime = baseTime + (100 * 86400000L) // Day 100 (doesn't exist)
        val result = WeightStatistics.binarySearchByDate(entries, targetTime)

        assertEquals(-1, result)
    }

    @Test
    fun binarySearchClosest_findsClosestEntry() {
        val baseTime = System.currentTimeMillis()
        val entries = (0..9).map { i ->
            WeightEntry(
                entryId = i + 1,
                userId = 1,
                weight = 200.0 - i,
                timestamp = baseTime + (i * 86400000L)
            )
        }

        // Search for time between day 3 and day 4 (closer to day 4)
        val targetTime = baseTime + (3 * 86400000L) + (60000000L) // Closer to day 4
        val result = WeightStatistics.binarySearchClosest(entries, targetTime)

        assertTrue(result == 3 || result == 4) // Should be one of the closest
    }

    // ==================== STATISTICS TESTS ====================

    @Test
    fun statistics_emptyListReturnsNull() {
        val entries = emptyList<WeightEntry>()
        val result = WeightStatistics.calculateStatistics(entries)
        assertNull(result)
    }

    @Test
    fun statistics_correctCalculation() {
        val entries = createTestEntries(listOf(200.0, 190.0, 195.0, 185.0, 180.0))
        val result = WeightStatistics.calculateStatistics(entries)

        assertNotNull(result)
        assertEquals(190.0, result!!.mean, 0.01) // Average
        assertEquals(180.0, result.min, 0.01) // Min
        assertEquals(200.0, result.max, 0.01) // Max
        assertEquals(5, result.count)
        assertEquals(20.0, result.range, 0.01) // 200 - 180
    }

    @Test
    fun weeklyRate_correctCalculation() {
        val baseTime = System.currentTimeMillis()
        val entries = listOf(
            WeightEntry(1, 1, 200.0, baseTime),
            WeightEntry(2, 1, 193.0, baseTime + (7 * 86400000L)) // 7 days later, lost 7 lbs
        )

        val weeklyRate = WeightStatistics.calculateWeeklyRate(entries)

        assertNotNull(weeklyRate)
        assertEquals(-7.0, weeklyRate!!, 0.1) // Lost 7 lbs per week
    }

    @Test
    fun weeklyRate_insufficientDataReturnsNull() {
        val entries = createTestEntries(listOf(200.0))
        val result = WeightStatistics.calculateWeeklyRate(entries)
        assertNull(result)
    }
}