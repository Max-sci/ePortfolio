package com.example.weight_trackingapp

import com.example.weight_trackingapp.data.local.entity.GoalWeight
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for GoalWeight entity.
 *
 * Tests progress calculation and remaining weight logic.
 */
class GoalWeightTest {

    // ==================== PROGRESS CALCULATION TESTS ====================

    @Test
    fun calculateProgress_atStartingWeightReturnsZero() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        val progress = goal.calculateProgress(200.0)

        assertEquals(0, progress)
    }

    @Test
    fun calculateProgress_atGoalWeightReturnsHundred() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        val progress = goal.calculateProgress(150.0)

        assertEquals(100, progress)
    }

    @Test
    fun calculateProgress_halfwayReturnsFifty() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        // Halfway between 200 and 150 is 175
        val progress = goal.calculateProgress(175.0)

        assertEquals(50, progress)
    }

    @Test
    fun calculateProgress_pastGoalReturnsHundred() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        // Below goal weight should still return 100
        val progress = goal.calculateProgress(140.0)

        assertEquals(100, progress)
    }

    @Test
    fun calculateProgress_aboveStartingReturnsZero() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        // Above starting weight should return 0
        val progress = goal.calculateProgress(210.0)

        assertEquals(0, progress)
    }

    // ==================== REMAINING WEIGHT TESTS ====================

    @Test
    fun remainingWeight_atStartingWeightReturnsFull() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        val remaining = goal.remainingWeight(200.0)

        assertEquals(50.0, remaining, 0.01)
    }

    @Test
    fun remainingWeight_atGoalReturnsZero() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        val remaining = goal.remainingWeight(150.0)

        assertEquals(0.0, remaining, 0.01)
    }

    @Test
    fun remainingWeight_pastGoalReturnsNegative() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        val remaining = goal.remainingWeight(140.0)

        assertEquals(-10.0, remaining, 0.01)
    }

    @Test
    fun remainingWeight_halfwayReturnsHalf() {
        val goal = GoalWeight(
            userId = 1,
            goalWeight = 150.0,
            startingWeight = 200.0
        )

        val remaining = goal.remainingWeight(175.0)

        assertEquals(25.0, remaining, 0.01)
    }
}