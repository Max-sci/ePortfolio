package com.example.weight_trackingapp.data.repository

import com.example.weight_trackingapp.data.local.dao.GoalWeightDao
import com.example.weight_trackingapp.data.local.dao.UserDao
import com.example.weight_trackingapp.data.local.dao.WeightEntryDao
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import com.example.weight_trackingapp.data.local.entity.User
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.util.SecurityUtils
import kotlinx.coroutines.flow.Flow

/**
 * Repository - Single source of truth for all data.
 *
 * MVVM ARCHITECTURE:
 * - ViewModels talk to Repository (not directly to database)
 * - Handles business logic (password hashing, validation)
 * - Could easily add remote data source later
 */
class WeightRepository(
    private val userDao: UserDao,
    private val weightEntryDao: WeightEntryDao,
    private val goalWeightDao: GoalWeightDao
) {

    // ==================== AUTH RESULTS ====================

    sealed class AuthResult {
        data class Success(val userId: Int, val username: String) : AuthResult()
        data class Error(val message: String) : AuthResult()
        object AccountLocked : AuthResult()
    }

    // ==================== USER OPERATIONS ====================

    /**
     * Registers a new user with secure password hashing.
     */
    suspend fun registerUser(username: String, password: String): AuthResult {
        // Validate username
        val usernameCheck = SecurityUtils.validateUsername(username)
        if (!usernameCheck.isValid) {
            return AuthResult.Error(usernameCheck.errorMessage)
        }

        // Validate password
        val passwordCheck = SecurityUtils.validatePassword(password)
        if (!passwordCheck.isValid) {
            return AuthResult.Error(passwordCheck.errorMessage)
        }

        // Check if username exists
        if (userDao.checkUserExists(username) > 0) {
            return AuthResult.Error("Username already exists")
        }

        // Hash password and create user
        val passwordHash = SecurityUtils.hashPassword(password)
        val user = User(
            username = SecurityUtils.sanitizeInput(username),
            passwordHash = passwordHash
        )

        return try {
            val userId = userDao.insertUser(user)
            AuthResult.Success(userId.toInt(), username)
        } catch (e: Exception) {
            AuthResult.Error("Registration failed")
        }
    }

    /**
     * Logs in a user with secure password verification.
     */
    suspend fun loginUser(username: String, password: String): AuthResult {
        val user = userDao.getUserByUsername(SecurityUtils.sanitizeInput(username))
            ?: return AuthResult.Error("Invalid username or password")

        // Check if account is locked
        if (user.isLocked) {
            return AuthResult.AccountLocked
        }

        // Verify password using bcrypt
        val isValid = SecurityUtils.verifyPassword(password, user.passwordHash)

        return if (isValid) {
            // Reset failed attempts on successful login
            userDao.updateFailedAttempts(user.userId, 0)
            AuthResult.Success(user.userId, user.username)
        } else {
            // Increment failed attempts
            val newAttempts = user.failedLoginAttempts + 1
            userDao.updateFailedAttempts(user.userId, newAttempts)

            // Lock account if too many failures
            if (newAttempts >= User.MAX_FAILED_ATTEMPTS) {
                userDao.setAccountLocked(user.userId, true)
                AuthResult.AccountLocked
            } else {
                val remaining = User.MAX_FAILED_ATTEMPTS - newAttempts
                AuthResult.Error("Invalid password. $remaining attempts left.")
            }
        }
    }

    // ==================== WEIGHT OPERATIONS ====================

    suspend fun addWeightEntry(userId: Int, weight: Double, notes: String? = null): Long {
        val entry = WeightEntry(
            userId = userId,
            weight = weight,
            notes = notes?.let { SecurityUtils.sanitizeInput(it) }
        )
        return weightEntryDao.insertWeightEntry(entry)
    }

    suspend fun deleteWeightEntry(entry: WeightEntry) {
        weightEntryDao.deleteWeightEntry(entry)
    }

    fun observeWeightEntries(userId: Int): Flow<List<WeightEntry>> {
        return weightEntryDao.getAllWeightEntriesByUser(userId)
    }

    fun observeLatestWeight(userId: Int): Flow<WeightEntry?> {
        return weightEntryDao.observeLatestWeightEntry(userId)
    }

    suspend fun getLatestWeight(userId: Int): WeightEntry? {
        return weightEntryDao.getLatestWeightEntry(userId)
    }

    // ==================== GOAL OPERATIONS ====================

    suspend fun setGoalWeight(userId: Int, goalWeight: Double, startingWeight: Double): Long {
        val goal = GoalWeight(
            userId = userId,
            goalWeight = goalWeight,
            startingWeight = startingWeight
        )
        return goalWeightDao.insertGoalWeight(goal)
    }

    suspend fun getGoalWeight(userId: Int): GoalWeight? {
        return goalWeightDao.getGoalWeightByUser(userId)
    }

    fun observeGoalWeight(userId: Int): Flow<GoalWeight?> {
        return goalWeightDao.observeGoalWeight(userId)
    }

    suspend fun markGoalAchieved(userId: Int) {
        goalWeightDao.markGoalAchieved(userId, System.currentTimeMillis())
    }
}