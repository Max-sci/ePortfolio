package com.example.weight_trackingapp.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.ui.dashboard.DashboardActivity
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Login Activity - Handles user authentication.
 *
 * MVVM ARCHITECTURE:
 * - View: This Activity (displays UI)
 * - ViewModel: LoginViewModel (handles logic)
 * - Model: Repository + Database (data)
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager

    // Views
    private lateinit var tilUsername: TextInputLayout
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etUsername: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var btnLogin: MaterialButton
    private lateinit var btnCreateAccount: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var tvErrorMessage: TextView

    // ViewModel with Factory
    private val viewModel: LoginViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        val repository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )
        LoginViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sessionManager = SecureSessionManager(this)

        // Check if already logged in
        if (sessionManager.isLoggedIn()) {
            navigateToDashboard()
            return
        }

        initializeViews()
        setupClickListeners()
        observeViewModel()
    }

    private fun initializeViews() {
        tilUsername = findViewById(R.id.tilUsername)
        tilPassword = findViewById(R.id.tilPassword)
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnCreateAccount = findViewById(R.id.btnCreateAccount)
        progressBar = findViewById(R.id.progressBar)
        tvErrorMessage = findViewById(R.id.tvErrorMessage)
    }

    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()
            viewModel.login(username, password)
        }

        btnCreateAccount.setOnClickListener {
            showRegisterDialog()
        }
    }

    private fun observeViewModel() {
        // Observe login state
        viewModel.loginState.observe(this) { state ->
            when (state) {
                is LoginViewModel.LoginState.Idle -> {
                    progressBar.visibility = View.GONE
                    tvErrorMessage.visibility = View.GONE
                }
                is LoginViewModel.LoginState.Loading -> {
                    progressBar.visibility = View.VISIBLE
                    tvErrorMessage.visibility = View.GONE
                }
                is LoginViewModel.LoginState.Success -> {
                    progressBar.visibility = View.GONE
                    sessionManager.createLoginSession(state.userId, state.username)
                    Toast.makeText(this, "Welcome, ${state.username}!", Toast.LENGTH_SHORT).show()
                    navigateToDashboard()
                }
                is LoginViewModel.LoginState.Error -> {
                    progressBar.visibility = View.GONE
                    tvErrorMessage.text = state.message
                    tvErrorMessage.visibility = View.VISIBLE
                }
                is LoginViewModel.LoginState.AccountLocked -> {
                    progressBar.visibility = View.GONE
                    showAccountLockedDialog()
                }
            }
        }

        // Observe field errors
        viewModel.usernameError.observe(this) { error ->
            tilUsername.error = error
        }

        viewModel.passwordError.observe(this) { error ->
            tilPassword.error = error
        }
    }

    private fun showRegisterDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_register, null)
        val etRegUsername = dialogView.findViewById<TextInputEditText>(R.id.etRegUsername)
        val etRegPassword = dialogView.findViewById<TextInputEditText>(R.id.etRegPassword)
        val etRegConfirmPassword = dialogView.findViewById<TextInputEditText>(R.id.etRegConfirmPassword)

        AlertDialog.Builder(this)
            .setTitle("Create Account")
            .setView(dialogView)
            .setPositiveButton("Register") { _, _ ->
                val username = etRegUsername.text.toString()
                val password = etRegPassword.text.toString()
                val confirmPassword = etRegConfirmPassword.text.toString()
                viewModel.register(username, password, confirmPassword)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAccountLockedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Account Locked")
            .setMessage("Too many failed login attempts. Please try again later.")
            .setPositiveButton("OK") { _, _ ->
                viewModel.resetState()
            }
            .setCancelable(false)
            .show()
    }

    private fun navigateToDashboard() {
        val intent = Intent(this, DashboardActivity::class.java)
        startActivity(intent)
        finish()
    }
}