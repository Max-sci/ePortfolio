package com.example.weight_trackingapp.ui.goal

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import com.example.weight_trackingapp.data.repository.WeightRepository
import kotlinx.coroutines.launch

/**
 * ViewModel for Goal Weight screen.
 *
 * HANDLES:
 * - Loading current goal
 * - Setting new goals
 * - Validating input
 */
class GoalWeightViewModel(
    private val repository: WeightRepository,
    private val userId: Int
) : ViewModel() {

    // ==================== UI STATE ====================

    sealed class SaveGoalResult {
        object Success : SaveGoalResult()
        data class Error(val message: String) : SaveGoalResult()
    }

    private val _saveGoalResult = MutableLiveData<SaveGoalResult?>()
    val saveGoalResult: LiveData<SaveGoalResult?> = _saveGoalResult

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    // Current goal (reactive)
    val currentGoal: LiveData<GoalWeight?> =
        repository.observeGoalWeight(userId).asLiveData()

    // ==================== USER ACTIONS ====================

    /**
     * Saves a new goal weight.
     */
    fun saveGoal(goalWeightStr: String, startingWeightStr: String) {
        // Validate goal weight
        val goalWeight = goalWeightStr.toDoubleOrNull()
        if (goalWeight == null) {
            _saveGoalResult.value = SaveGoalResult.Error("Please enter a valid goal weight")
            return
        }

        // Validate starting weight
        val startingWeight = startingWeightStr.toDoubleOrNull()
        if (startingWeight == null) {
            _saveGoalResult.value = SaveGoalResult.Error("Please enter a valid starting weight")
            return
        }

        // Validate ranges
        if (goalWeight <= 0 || goalWeight > 1000) {
            _saveGoalResult.value = SaveGoalResult.Error("Goal weight must be between 1-1000 lbs")
            return
        }

        if (startingWeight <= 0 || startingWeight > 1000) {
            _saveGoalResult.value = SaveGoalResult.Error("Starting weight must be between 1-1000 lbs")
            return
        }

        if (goalWeight >= startingWeight) {
            _saveGoalResult.value = SaveGoalResult.Error("Goal weight must be less than starting weight")
            return
        }

        _isLoading.value = true

        viewModelScope.launch {
            try {
                val goalId = repository.setGoalWeight(userId, goalWeight, startingWeight)
                if (goalId > 0) {
                    _saveGoalResult.value = SaveGoalResult.Success
                } else {
                    _saveGoalResult.value = SaveGoalResult.Error("Failed to save goal")
                }
            } catch (e: Exception) {
                _saveGoalResult.value = SaveGoalResult.Error("Error: ${e.message}")
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Clears the save result.
     */
    fun clearSaveResult() {
        _saveGoalResult.value = null
    }
}