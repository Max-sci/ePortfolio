package com.example.weight_trackingapp.algorithms

import com.example.weight_trackingapp.data.local.entity.WeightEntry
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Weight Statistics and Algorithms
 *
 * ALGORITHMS IMPLEMENTED:
 * 1. Moving Average (7-day weighted) - O(n) time complexity
 * 2. Linear Regression for Prediction - O(n) time complexity
 * 3. Binary Search for Date Lookup - O(log n) time complexity
 * 4. Statistical Analysis (mean, std dev, min, max)
 *
 * COURSE OUTCOME 3: Design and evaluate computing solutions using algorithmic principles
 * COURSE OUTCOME 4: Use well-founded techniques and tools in computing practices
 */
object WeightStatistics {

    // ==================== DATA CLASS FOR REGRESSION RESULTS ====================

    /**
     * Holds the results of linear regression calculation.
     * slope: rate of weight change per day
     * intercept: starting weight value
     * rSquared: coefficient of determination (0-1, higher = better fit)
     */
    data class RegressionResult(
        val slope: Double,
        val intercept: Double,
        val rSquared: Double
    )

    /**
     * Holds comprehensive statistics about weight data.
     */
    data class StatisticsResult(
        val mean: Double,
        val standardDeviation: Double,
        val min: Double,
        val max: Double,
        val count: Int,
        val range: Double
    )

    // ==================== MOVING AVERAGE ALGORITHM ====================

    /**
     * Calculates a 7-day weighted moving average.
     *
     * More recent days have higher weights to better reflect current trends.
     * Weights: [1, 2, 3, 4, 5, 6, 7] - most recent day has weight 7
     *
     * TIME COMPLEXITY: O(n) where n is the number of entries
     * SPACE COMPLEXITY: O(n) for the result list
     *
     * @param entries List of weight entries sorted by date (oldest first)
     * @param windowSize Number of days for the moving average (default 7)
     * @return List of moving averages corresponding to each valid position
     */
    fun calculateMovingAverage(
        entries: List<WeightEntry>,
        windowSize: Int = 7
    ): List<Double> {
        if (entries.size < windowSize) {
            // Not enough data points, return simple average of available data
            return if (entries.isEmpty()) {
                emptyList()
            } else {
                listOf(entries.map { it.weight }.average())
            }
        }

        val movingAverages = mutableListOf<Double>()

        // Generate weights: [1, 2, 3, ..., windowSize]
        val weights = (1..windowSize).map { it.toDouble() }
        val totalWeight = weights.sum()

        // Calculate weighted moving average for each valid window
        for (i in (windowSize - 1) until entries.size) {
            var weightedSum = 0.0

            for (j in 0 until windowSize) {
                val entryIndex = i - windowSize + 1 + j
                weightedSum += entries[entryIndex].weight * weights[j]
            }

            movingAverages.add(weightedSum / totalWeight)
        }

        return movingAverages
    }

    /**
     * Calculates a simple moving average (unweighted).
     *
     * TIME COMPLEXITY: O(n)
     * SPACE COMPLEXITY: O(n)
     */
    fun calculateSimpleMovingAverage(
        entries: List<WeightEntry>,
        windowSize: Int = 7
    ): List<Double> {
        if (entries.size < windowSize) {
            return if (entries.isEmpty()) emptyList()
            else listOf(entries.map { it.weight }.average())
        }

        val movingAverages = mutableListOf<Double>()

        for (i in (windowSize - 1) until entries.size) {
            val window = entries.subList(i - windowSize + 1, i + 1)
            val average = window.map { it.weight }.average()
            movingAverages.add(average)
        }

        return movingAverages
    }

    // ==================== LINEAR REGRESSION ALGORITHM ====================

    /**
     * Calculates linear regression using least squares method.
     *
     * Formula for slope (m): m = (n*Σxy - Σx*Σy) / (n*Σx² - (Σx)²)
     * Formula for intercept (b): b = (Σy - m*Σx) / n
     *
     * TIME COMPLEXITY: O(n) - single pass through data
     * SPACE COMPLEXITY: O(1) - constant extra space
     *
     * @param entries List of weight entries sorted by date (oldest first)
     * @return RegressionResult containing slope, intercept, and R² value
     */
    fun calculateLinearRegression(entries: List<WeightEntry>): RegressionResult? {
        val n = entries.size

        if (n < 2) {
            return null // Need at least 2 points for regression
        }

        var sumX = 0.0
        var sumY = 0.0
        var sumXY = 0.0
        var sumX2 = 0.0
        var sumY2 = 0.0

        // Single pass through data - O(n)
        for (i in entries.indices) {
            val x = i.toDouble() // Day number (0, 1, 2, ...)
            val y = entries[i].weight

            sumX += x
            sumY += y
            sumXY += x * y
            sumX2 += x * x
            sumY2 += y * y
        }

        // Calculate slope (m)
        val denominator = n * sumX2 - sumX * sumX
        if (denominator == 0.0) {
            return null // Cannot compute (would divide by zero)
        }

        val slope = (n * sumXY - sumX * sumY) / denominator

        // Calculate intercept (b)
        val intercept = (sumY - slope * sumX) / n

        // Calculate R² (coefficient of determination)
        val yMean = sumY / n
        var ssTotal = 0.0  // Total sum of squares
        var ssResidual = 0.0  // Residual sum of squares

        for (i in entries.indices) {
            val x = i.toDouble()
            val y = entries[i].weight
            val yPredicted = slope * x + intercept

            ssTotal += (y - yMean).pow(2)
            ssResidual += (y - yPredicted).pow(2)
        }

        val rSquared = if (ssTotal > 0) 1 - (ssResidual / ssTotal) else 0.0

        return RegressionResult(slope, intercept, rSquared)
    }

    /**
     * Predicts future weight using linear regression results.
     *
     * TIME COMPLEXITY: O(1) - constant time calculation
     *
     * @param regression The regression result from calculateLinearRegression
     * @param currentIndex The current day index (number of existing entries)
     * @param daysFromNow How many days into the future to predict
     * @return Predicted weight value
     */
    fun predictWeight(
        regression: RegressionResult,
        currentIndex: Int,
        daysFromNow: Int
    ): Double {
        val futureDay = currentIndex + daysFromNow
        return regression.slope * futureDay + regression.intercept
    }

    /**
     * Estimates days until goal weight is reached based on current trend.
     *
     * @param regression The regression result
     * @param currentIndex Current day index
     * @param goalWeight Target weight
     * @return Estimated days until goal, or null if goal won't be reached with current trend
     */
    fun estimateDaysToGoal(
        regression: RegressionResult,
        currentIndex: Int,
        goalWeight: Double
    ): Int? {
        // If slope is 0 or positive (gaining/maintaining), won't reach lower goal
        if (regression.slope >= 0 && goalWeight < regression.intercept + regression.slope * currentIndex) {
            return null
        }

        // If slope is 0 or negative (losing/maintaining), won't reach higher goal
        if (regression.slope <= 0 && goalWeight > regression.intercept + regression.slope * currentIndex) {
            return null
        }

        // Calculate when predicted weight = goal weight
        // goalWeight = slope * futureDay + intercept
        // futureDay = (goalWeight - intercept) / slope
        val futureDay = (goalWeight - regression.intercept) / regression.slope
        val daysFromNow = (futureDay - currentIndex).toInt()

        return if (daysFromNow > 0) daysFromNow else null
    }

    // ==================== BINARY SEARCH ALGORITHM ====================

    /**
     * Binary search to find a weight entry by timestamp.
     *
     * TIME COMPLEXITY: O(log n) - divides search space in half each iteration
     * SPACE COMPLEXITY: O(1) - iterative implementation
     *
     * Comparison with linear search:
     * - Linear search: O(n) - checks every element
     * - Binary search: O(log n) - much faster for large datasets
     *
     * Example: For 1000 entries:
     * - Linear search: up to 1000 comparisons
     * - Binary search: up to 10 comparisons (log₂1000 ≈ 10)
     *
     * @param entries List of weight entries sorted by timestamp (oldest first)
     * @param targetTimestamp The timestamp to search for
     * @return Index of the entry, or -1 if not found
     */
    fun binarySearchByDate(
        entries: List<WeightEntry>,
        targetTimestamp: Long
    ): Int {
        if (entries.isEmpty()) return -1

        var left = 0
        var right = entries.size - 1

        while (left <= right) {
            val mid = left + (right - left) / 2  // Prevents integer overflow
            val midTimestamp = entries[mid].timestamp

            when {
                midTimestamp == targetTimestamp -> return mid
                midTimestamp < targetTimestamp -> left = mid + 1
                else -> right = mid - 1
            }
        }

        return -1 // Not found
    }

    /**
     * Binary search to find the closest entry to a target date.
     *
     * TIME COMPLEXITY: O(log n)
     *
     * @param entries Sorted list of weight entries
     * @param targetTimestamp Target timestamp
     * @return Index of the closest entry, or -1 if list is empty
     */
    fun binarySearchClosest(
        entries: List<WeightEntry>,
        targetTimestamp: Long
    ): Int {
        if (entries.isEmpty()) return -1
        if (entries.size == 1) return 0

        var left = 0
        var right = entries.size - 1

        while (left < right - 1) {
            val mid = left + (right - left) / 2

            when {
                entries[mid].timestamp == targetTimestamp -> return mid
                entries[mid].timestamp < targetTimestamp -> left = mid
                else -> right = mid
            }
        }

        // Return the closer of the two remaining candidates
        val leftDiff = kotlin.math.abs(entries[left].timestamp - targetTimestamp)
        val rightDiff = kotlin.math.abs(entries[right].timestamp - targetTimestamp)

        return if (leftDiff <= rightDiff) left else right
    }

    /**
     * Binary search to find entries within a date range.
     *
     * TIME COMPLEXITY: O(log n + k) where k is the number of results
     *
     * @param entries Sorted list of weight entries
     * @param startTimestamp Start of range (inclusive)
     * @param endTimestamp End of range (inclusive)
     * @return List of entries within the range
     */
    fun findEntriesInRange(
        entries: List<WeightEntry>,
        startTimestamp: Long,
        endTimestamp: Long
    ): List<WeightEntry> {
        if (entries.isEmpty()) return emptyList()

        // Find starting position using binary search
        var left = 0
        var right = entries.size - 1
        var startIndex = entries.size

        // Find first entry >= startTimestamp
        while (left <= right) {
            val mid = left + (right - left) / 2
            if (entries[mid].timestamp >= startTimestamp) {
                startIndex = mid
                right = mid - 1
            } else {
                left = mid + 1
            }
        }

        // Collect entries until we exceed endTimestamp
        val result = mutableListOf<WeightEntry>()
        for (i in startIndex until entries.size) {
            if (entries[i].timestamp <= endTimestamp) {
                result.add(entries[i])
            } else {
                break
            }
        }

        return result
    }

    // ==================== STATISTICAL ANALYSIS ====================

    /**
     * Calculates comprehensive statistics for weight data.
     *
     * TIME COMPLEXITY: O(n) - two passes through data
     * SPACE COMPLEXITY: O(1) - constant extra space
     *
     * @param entries List of weight entries
     * @return StatisticsResult with mean, std dev, min, max, count, range
     */
    fun calculateStatistics(entries: List<WeightEntry>): StatisticsResult? {
        if (entries.isEmpty()) return null

        val weights = entries.map { it.weight }
        val count = weights.size
        val sum = weights.sum()
        val mean = sum / count
        val min = weights.minOrNull() ?: 0.0
        val max = weights.maxOrNull() ?: 0.0
        val range = max - min

        // Calculate standard deviation
        val squaredDifferences = weights.map { (it - mean).pow(2) }
        val variance = squaredDifferences.sum() / count
        val standardDeviation = sqrt(variance)

        return StatisticsResult(
            mean = mean,
            standardDeviation = standardDeviation,
            min = min,
            max = max,
            count = count,
            range = range
        )
    }

    /**
     * Calculates the rate of weight change per week.
     *
     * @param entries List of weight entries sorted by date
     * @return Average weight change per week, or null if insufficient data
     */
    fun calculateWeeklyRate(entries: List<WeightEntry>): Double? {
        if (entries.size < 2) return null

        val firstEntry = entries.first()
        val lastEntry = entries.last()

        val totalWeightChange = lastEntry.weight - firstEntry.weight
        val totalDays = (lastEntry.timestamp - firstEntry.timestamp) / (1000 * 60 * 60 * 24.0)

        if (totalDays < 1) return null

        val dailyRate = totalWeightChange / totalDays
        return dailyRate * 7 // Convert to weekly rate
    }
}