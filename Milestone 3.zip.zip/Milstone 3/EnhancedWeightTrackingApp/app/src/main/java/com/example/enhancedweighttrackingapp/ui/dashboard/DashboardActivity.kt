package com.example.weight_trackingapp.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.ui.analytics.AnalyticsActivity
import com.example.weight_trackingapp.ui.goal.GoalWeightActivity
import com.example.weight_trackingapp.ui.history.WeightHistoryActivity
import com.example.weight_trackingapp.ui.login.LoginActivity
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dashboard Activity - Main screen after login.
 *
 * DISPLAYS:
 * - Current weight
 * - Goal progress
 * - Milestone achievements
 */
class DashboardActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager

    // Views
    private lateinit var toolbar: MaterialToolbar
    private lateinit var tvWelcome: TextView
    private lateinit var tvCurrentWeight: TextView
    private lateinit var tvLastUpdated: TextView
    private lateinit var tvGoalWeight: TextView
    private lateinit var tvProgressPercent: TextView
    private lateinit var tvRemainingWeight: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var progressBarLoading: ProgressBar
    private lateinit var btnLogWeight: MaterialButton
    private lateinit var btnViewHistory: MaterialButton
    private lateinit var btnSetGoal: MaterialButton
    private lateinit var btnAnalytics: MaterialButton

    // ViewModel
    private val viewModel: DashboardViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        val repository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )
        DashboardViewModelFactory(repository, sessionManager.getUserId())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        sessionManager = SecureSessionManager(this)

        // Check if logged in
        if (!sessionManager.isLoggedIn()) {
            navigateToLogin()
            return
        }

        initializeViews()
        setupToolbar()
        setupClickListeners()
        observeViewModel()

        // Refresh session
        sessionManager.refreshSession()
    }

    override fun onResume() {
        super.onResume()
        viewModel.refresh()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        tvWelcome = findViewById(R.id.tvWelcome)
        tvCurrentWeight = findViewById(R.id.tvCurrentWeight)
        tvLastUpdated = findViewById(R.id.tvLastUpdated)
        tvGoalWeight = findViewById(R.id.tvGoalWeight)
        tvProgressPercent = findViewById(R.id.tvProgressPercent)
        tvRemainingWeight = findViewById(R.id.tvRemainingWeight)
        progressBar = findViewById(R.id.progressBar)
        progressBarLoading = findViewById(R.id.progressBarLoading)
        btnLogWeight = findViewById(R.id.btnLogWeight)
        btnViewHistory = findViewById(R.id.btnViewHistory)
        btnSetGoal = findViewById(R.id.btnSetGoal)
        btnAnalytics = findViewById(R.id.btnAnalytics)

        // Set welcome message
        tvWelcome.text = "Welcome back, ${sessionManager.getUsername()}!"
    }

    private fun setupToolbar() {
        toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_logout -> {
                    showLogoutDialog()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupClickListeners() {
        btnLogWeight.setOnClickListener {
            startActivity(Intent(this, WeightHistoryActivity::class.java))
        }

        btnViewHistory.setOnClickListener {
            startActivity(Intent(this, WeightHistoryActivity::class.java))
        }

        btnSetGoal.setOnClickListener {
            startActivity(Intent(this, GoalWeightActivity::class.java))
        }

        btnAnalytics.setOnClickListener {
            startActivity(Intent(this, AnalyticsActivity::class.java))
        }
    }

    private fun observeViewModel() {
        // Observe loading state
        viewModel.isLoading.observe(this) { isLoading ->
            progressBarLoading.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Observe dashboard state
        viewModel.dashboardState.observe(this) { state ->
            updateWeightDisplay(state)
            updateGoalDisplay(state)
            updateProgressDisplay(state)

            // Show milestone if achieved
            state.milestone?.let { showMilestoneDialog(it) }
        }
    }

    private fun updateWeightDisplay(state: DashboardViewModel.DashboardState) {
        if (state.latestWeight != null) {
            tvCurrentWeight.text = String.format(Locale.getDefault(), "%.1f", state.latestWeight.weight)

            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            val date = Date(state.latestWeight.timestamp)
            tvLastUpdated.text = "Last updated: ${dateFormat.format(date)}"
        } else {
            tvCurrentWeight.text = "--"
            tvLastUpdated.text = "No weight entries yet"
        }
    }

    private fun updateGoalDisplay(state: DashboardViewModel.DashboardState) {
        if (state.goalWeight != null) {
            tvGoalWeight.text = String.format(Locale.getDefault(), "Goal: %.1f lbs", state.goalWeight.goalWeight)
        } else {
            tvGoalWeight.text = "Goal: --"
            tvRemainingWeight.text = "Set your goal to track progress"
        }
    }

    private fun updateProgressDisplay(state: DashboardViewModel.DashboardState) {
        if (state.goalWeight == null || state.latestWeight == null) {
            progressBar.progress = 0
            tvProgressPercent.text = "0%"
            return
        }

        progressBar.progress = state.progress
        tvProgressPercent.text = "${state.progress}%"

        if (state.remainingWeight <= 0) {
            tvRemainingWeight.text = "Goal achieved! 🎉"
        } else {
            tvRemainingWeight.text = String.format(Locale.getDefault(), "%.1f lbs to go!", state.remainingWeight)
        }
    }

    private fun showMilestoneDialog(milestone: DashboardViewModel.Milestone) {
        val message = when (milestone) {
            DashboardViewModel.Milestone.GOAL_REACHED -> "🎉 Congratulations! You've reached your goal!"
            DashboardViewModel.Milestone.FIVE_POUNDS_LEFT -> "🔥 Only 5 lbs away from your goal!"
            DashboardViewModel.Milestone.TEN_POUNDS_LEFT -> "💪 Only 10 lbs to go!"
            DashboardViewModel.Milestone.TWENTY_POUNDS_LEFT -> "⭐ 20 lbs away from your goal!"
        }

        AlertDialog.Builder(this)
            .setTitle("Milestone!")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                sessionManager.logout()
                navigateToLogin()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}