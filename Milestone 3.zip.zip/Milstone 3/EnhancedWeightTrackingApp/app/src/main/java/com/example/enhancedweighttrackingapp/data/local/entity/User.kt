package com.example.weight_trackingapp.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * User Entity - Represents a user in the weight tracking application.
 *
 * SECURITY ENHANCEMENTS:
 * - Password stored as bcrypt hash (never plaintext!)
 * - Tracks failed login attempts for brute force protection
 * - Account lockout after too many failed attempts
 */
@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class User(
    @PrimaryKey(autoGenerate = true)
    val userId: Int = 0,

    val username: String,

    val passwordHash: String,  // SECURE: Never store plain passwords!

    val createdAt: Long = System.currentTimeMillis(),

    val failedLoginAttempts: Int = 0,

    val isLocked: Boolean = false
) {
    companion object {
        const val MAX_FAILED_ATTEMPTS = 5
    }
}