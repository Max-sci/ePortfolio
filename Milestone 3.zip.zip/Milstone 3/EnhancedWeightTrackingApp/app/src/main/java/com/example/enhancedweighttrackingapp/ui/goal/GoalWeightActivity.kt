package com.example.weight_trackingapp.ui.goal

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale

/**
 * Goal Weight Activity - Set weight loss goals.
 */
class GoalWeightActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager

    // Views
    private lateinit var toolbar: MaterialToolbar
    private lateinit var etGoalWeight: TextInputEditText
    private lateinit var etStartingWeight: TextInputEditText
    private lateinit var btnSaveGoal: MaterialButton
    private lateinit var progressBar: ProgressBar

    // ViewModel
    private val viewModel: GoalWeightViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        val repository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )
        GoalWeightViewModelFactory(repository, sessionManager.getUserId())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal_weight)

        sessionManager = SecureSessionManager(this)

        initializeViews()
        setupToolbar()
        setupClickListeners()
        observeViewModel()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        etGoalWeight = findViewById(R.id.etGoalWeight)
        etStartingWeight = findViewById(R.id.etStartingWeight)
        btnSaveGoal = findViewById(R.id.btnSaveGoal)
        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupToolbar() {
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupClickListeners() {
        btnSaveGoal.setOnClickListener {
            val goalWeight = etGoalWeight.text.toString()
            val startingWeight = etStartingWeight.text.toString()
            viewModel.saveGoal(goalWeight, startingWeight)
        }
    }

    private fun observeViewModel() {
        // Observe loading state
        viewModel.isLoading.observe(this) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            btnSaveGoal.isEnabled = !isLoading
        }

        // Observe current goal to pre-fill fields
        viewModel.currentGoal.observe(this) { goal ->
            if (goal != null) {
                etGoalWeight.setText(String.format(Locale.getDefault(), "%.1f", goal.goalWeight))
                etStartingWeight.setText(String.format(Locale.getDefault(), "%.1f", goal.startingWeight))
            }
        }

        // Observe save result
        viewModel.saveGoalResult.observe(this) { result ->
            when (result) {
                is GoalWeightViewModel.SaveGoalResult.Success -> {
                    Toast.makeText(this, "Goal saved!", Toast.LENGTH_SHORT).show()
                    viewModel.clearSaveResult()
                    finish()
                }
                is GoalWeightViewModel.SaveGoalResult.Error -> {
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    viewModel.clearSaveResult()
                }
                null -> { /* Do nothing */ }
            }
        }
    }
}