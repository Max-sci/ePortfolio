package com.example.weight_trackingapp.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.weight_trackingapp.data.local.dao.GoalWeightDao
import com.example.weight_trackingapp.data.local.dao.UserDao
import com.example.weight_trackingapp.data.local.dao.WeightEntryDao
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import com.example.weight_trackingapp.data.local.entity.User
import com.example.weight_trackingapp.data.local.entity.WeightEntry

/**
 * Room Database for the Weight Tracking Application.
 *
 * DESIGN IMPROVEMENTS:
 * - Thread-safe singleton pattern
 * - No main thread queries (async only)
 * - Clean separation of DAOs
 */
@Database(
    entities = [User::class, WeightEntry::class, GoalWeight::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun weightEntryDao(): WeightEntryDao
    abstract fun goalWeightDao(): GoalWeightDao

    companion object {
        private const val DATABASE_NAME = "weight_tracker_db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DATABASE_NAME
            )
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}