package com.example.weight_trackingapp.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for WeightEntry operations.
 *
 * DESIGN IMPROVEMENTS:
 * - Flow for reactive UI updates
 * - Suspend functions for async operations
 * - Useful queries for statistics
 */
@Dao
interface WeightEntryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightEntry(weightEntry: WeightEntry): Long

    @Delete
    suspend fun deleteWeightEntry(weightEntry: WeightEntry)

    @Query("DELETE FROM weight_entries WHERE entryId = :entryId")
    suspend fun deleteWeightEntryById(entryId: Int)

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC")
    fun getAllWeightEntriesByUser(userId: Int): Flow<List<WeightEntry>>

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp ASC")
    suspend fun getAllEntriesOnce(userId: Int): List<WeightEntry>

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestWeightEntry(userId: Int): WeightEntry?

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC LIMIT 1")
    fun observeLatestWeightEntry(userId: Int): Flow<WeightEntry?>

    @Query("SELECT COUNT(*) FROM weight_entries WHERE userId = :userId")
    suspend fun getEntryCount(userId: Int): Int

    @Query("SELECT MIN(weight) FROM weight_entries WHERE userId = :userId")
    suspend fun getMinWeight(userId: Int): Double?

    @Query("SELECT MAX(weight) FROM weight_entries WHERE userId = :userId")
    suspend fun getMaxWeight(userId: Int): Double?

    @Query("SELECT AVG(weight) FROM weight_entries WHERE userId = :userId")
    suspend fun getAverageWeight(userId: Int): Double?
}