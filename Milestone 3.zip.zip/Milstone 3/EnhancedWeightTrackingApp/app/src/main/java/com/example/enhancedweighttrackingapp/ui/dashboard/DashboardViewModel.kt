package com.example.weight_trackingapp.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.data.repository.WeightRepository
import kotlinx.coroutines.launch

/**
 * ViewModel for Dashboard screen.
 *
 * RESPONSIBILITIES:
 * - Combines weight and goal data
 * - Calculates progress
 * - Detects milestones
 */
class DashboardViewModel(
    private val repository: WeightRepository,
    private val userId: Int
) : ViewModel() {

    // ==================== UI STATE ====================

    data class DashboardState(
        val latestWeight: WeightEntry? = null,
        val goalWeight: GoalWeight? = null,
        val progress: Int = 0,
        val remainingWeight: Double = 0.0,
        val milestone: Milestone? = null
    )

    enum class Milestone {
        GOAL_REACHED,
        FIVE_POUNDS_LEFT,
        TEN_POUNDS_LEFT,
        TWENTY_POUNDS_LEFT
    }

    private val _dashboardState = MutableLiveData<DashboardState>()
    val dashboardState: LiveData<DashboardState> = _dashboardState

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    // Reactive data streams
    val latestWeight: LiveData<WeightEntry?> =
        repository.observeLatestWeight(userId).asLiveData()

    val goalWeight: LiveData<GoalWeight?> =
        repository.observeGoalWeight(userId).asLiveData()

    init {
        loadDashboardData()
    }

    /**
     * Loads and combines dashboard data.
     */
    fun loadDashboardData() {
        _isLoading.value = true

        viewModelScope.launch {
            val weight = repository.getLatestWeight(userId)
            val goal = repository.getGoalWeight(userId)

            val state = calculateState(weight, goal)
            _dashboardState.value = state
            _isLoading.value = false
        }
    }

    /**
     * Calculates the dashboard state.
     */
    private fun calculateState(weight: WeightEntry?, goal: GoalWeight?): DashboardState {
        if (weight == null || goal == null) {
            return DashboardState(weight, goal)
        }

        val progress = goal.calculateProgress(weight.weight)
        val remaining = goal.remainingWeight(weight.weight)
        val milestone = detectMilestone(remaining)

        return DashboardState(
            latestWeight = weight,
            goalWeight = goal,
            progress = progress,
            remainingWeight = remaining,
            milestone = milestone
        )
    }

    /**
     * Detects milestone achievements.
     */
    private fun detectMilestone(remaining: Double): Milestone? {
        return when {
            remaining <= 0 -> Milestone.GOAL_REACHED
            remaining <= 5 -> Milestone.FIVE_POUNDS_LEFT
            remaining <= 10 -> Milestone.TEN_POUNDS_LEFT
            remaining <= 20 -> Milestone.TWENTY_POUNDS_LEFT
            else -> null
        }
    }

    /**
     * Refreshes dashboard data.
     */
    fun refresh() {
        loadDashboardData()
    }
}