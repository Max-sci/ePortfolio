package com.example.weight_trackingapp

import com.example.weight_trackingapp.data.export.DataValidator
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for DataValidator.
 *
 * Tests:
 * - Weight validation
 * - Username validation
 * - Password validation
 * - Input sanitization
 *
 * COURSE OUTCOME 5: Security mindset in database operations
 */
class DataValidatorTest {

    // ==================== WEIGHT VALIDATION TESTS ====================

    @Test
    fun validateWeight_validWeight_returnsSuccess() {
        val result = DataValidator.validateWeight(150.0)
        assertTrue(result.isValid())
    }

    @Test
    fun validateWeight_nullWeight_returnsError() {
        val result = DataValidator.validateWeight(null)
        assertFalse(result.isValid())
        assertEquals("Weight is required", result.getErrorMessage())
    }

    @Test
    fun validateWeight_zeroWeight_returnsError() {
        val result = DataValidator.validateWeight(0.0)
        assertFalse(result.isValid())
        assertEquals("Weight must be positive", result.getErrorMessage())
    }

    @Test
    fun validateWeight_negativeWeight_returnsError() {
        val result = DataValidator.validateWeight(-10.0)
        assertFalse(result.isValid())
    }

    @Test
    fun validateWeight_tooLow_returnsError() {
        val result = DataValidator.validateWeight(30.0) // Below MIN_WEIGHT (50)
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("at least") == true)
    }

    @Test
    fun validateWeight_tooHigh_returnsError() {
        val result = DataValidator.validateWeight(1500.0) // Above MAX_WEIGHT (1000)
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("less than") == true)
    }

    @Test
    fun validateWeight_atMinBoundary_returnsSuccess() {
        val result = DataValidator.validateWeight(DataValidator.MIN_WEIGHT)
        assertTrue(result.isValid())
    }

    @Test
    fun validateWeight_atMaxBoundary_returnsSuccess() {
        val result = DataValidator.validateWeight(DataValidator.MAX_WEIGHT)
        assertTrue(result.isValid())
    }

    // ==================== WEIGHT STRING PARSING TESTS ====================

    @Test
    fun validateAndParseWeight_validString_returnsWeight() {
        val (result, weight) = DataValidator.validateAndParseWeight("185.5")
        assertTrue(result.isValid())
        assertEquals(185.5, weight!!, 0.01)
    }

    @Test
    fun validateAndParseWeight_blankString_returnsError() {
        val (result, weight) = DataValidator.validateAndParseWeight("")
        assertFalse(result.isValid())
        assertNull(weight)
    }

    @Test
    fun validateAndParseWeight_invalidFormat_returnsError() {
        val (result, weight) = DataValidator.validateAndParseWeight("abc")
        assertFalse(result.isValid())
        assertNull(weight)
        assertEquals("Invalid weight format", result.getErrorMessage())
    }

    @Test
    fun validateAndParseWeight_withWhitespace_parsesCorrectly() {
        val (result, weight) = DataValidator.validateAndParseWeight("  175.0  ")
        assertTrue(result.isValid())
        assertEquals(175.0, weight!!, 0.01)
    }

    // ==================== USERNAME VALIDATION TESTS ====================

    @Test
    fun validateUsername_validUsername_returnsSuccess() {
        val result = DataValidator.validateUsername("john_doe123")
        assertTrue(result.isValid())
    }

    @Test
    fun validateUsername_nullUsername_returnsError() {
        val result = DataValidator.validateUsername(null)
        assertFalse(result.isValid())
        assertEquals("Username is required", result.getErrorMessage())
    }

    @Test
    fun validateUsername_tooShort_returnsError() {
        val result = DataValidator.validateUsername("ab") // Less than 3 chars
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("at least") == true)
    }

    @Test
    fun validateUsername_withSpecialChars_returnsError() {
        val result = DataValidator.validateUsername("john@doe")
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("only contain") == true)
    }

    @Test
    fun validateUsername_withSpaces_returnsError() {
        val result = DataValidator.validateUsername("john doe")
        assertFalse(result.isValid())
    }

    // ==================== PASSWORD VALIDATION TESTS ====================

    @Test
    fun validatePassword_validPassword_returnsSuccess() {
        val result = DataValidator.validatePassword("secure123")
        assertTrue(result.isValid())
    }

    @Test
    fun validatePassword_nullPassword_returnsError() {
        val result = DataValidator.validatePassword(null)
        assertFalse(result.isValid())
        assertEquals("Password is required", result.getErrorMessage())
    }

    @Test
    fun validatePassword_tooShort_returnsError() {
        val result = DataValidator.validatePassword("abc") // Less than 4 chars
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("at least") == true)
    }

    // ==================== TIMESTAMP VALIDATION TESTS ====================

    @Test
    fun validateTimestamp_currentTime_returnsSuccess() {
        val result = DataValidator.validateTimestamp(System.currentTimeMillis())
        assertTrue(result.isValid())
    }

    @Test
    fun validateTimestamp_nullTimestamp_returnsError() {
        val result = DataValidator.validateTimestamp(null)
        assertFalse(result.isValid())
    }

    @Test
    fun validateTimestamp_tooOld_returnsError() {
        val twoYearsAgo = System.currentTimeMillis() - (2L * 365 * 24 * 60 * 60 * 1000)
        val result = DataValidator.validateTimestamp(twoYearsAgo)
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("past") == true)
    }

    @Test
    fun validateTimestamp_future_returnsError() {
        val nextWeek = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000)
        val result = DataValidator.validateTimestamp(nextWeek)
        assertFalse(result.isValid())
        assertTrue(result.getErrorMessage()?.contains("future") == true)
    }

    // ==================== SANITIZATION TESTS ====================

    @Test
    fun sanitizeString_normalString_returnsUnchanged() {
        val result = DataValidator.sanitizeString("Hello World")
        assertEquals("Hello World", result)
    }

    @Test
    fun sanitizeString_nullString_returnsEmpty() {
        val result = DataValidator.sanitizeString(null)
        assertEquals("", result)
    }

    @Test
    fun sanitizeString_withHtmlTags_removesTagChars() {
        val result = DataValidator.sanitizeString("<script>alert('xss')</script>")
        assertFalse(result.contains("<"))
        assertFalse(result.contains(">"))
    }

    @Test
    fun sanitizeString_withSqlChars_removesQuotes() {
        val result = DataValidator.sanitizeString("Robert'; DROP TABLE users;--")
        assertFalse(result.contains("'"))
    }

    @Test
    fun sanitizeString_withWhitespace_trims() {
        val result = DataValidator.sanitizeString("  hello  ")
        assertEquals("hello", result)
    }

    // ==================== WEIGHT ENTRY VALIDATION TESTS ====================

    @Test
    fun validateWeightEntry_allValid_returnsSuccess() {
        val result = DataValidator.validateWeightEntry(
            weight = 175.0,
            timestamp = System.currentTimeMillis(),
            userId = 1
        )
        assertTrue(result.isValid())
    }

    @Test
    fun validateWeightEntry_invalidUserId_returnsError() {
        val result = DataValidator.validateWeightEntry(
            weight = 175.0,
            timestamp = System.currentTimeMillis(),
            userId = 0
        )
        assertFalse(result.isValid())
        assertEquals("Invalid user", result.getErrorMessage())
    }

    @Test
    fun validateWeightEntry_invalidWeight_returnsError() {
        val result = DataValidator.validateWeightEntry(
            weight = -10.0,
            timestamp = System.currentTimeMillis(),
            userId = 1
        )
        assertFalse(result.isValid())
    }
}