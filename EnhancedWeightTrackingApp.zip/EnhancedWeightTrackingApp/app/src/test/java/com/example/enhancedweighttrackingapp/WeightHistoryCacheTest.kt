package com.example.weight_trackingapp

import com.example.weight_trackingapp.algorithms.WeightHistoryCache
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Unit tests for WeightHistoryCache custom data structure.
 *
 * Tests:
 * - O(1) HashMap lookup by date
 * - O(1) ArrayList access by index
 * - Sorted insertion maintenance
 * - Range queries using binary search
 */
class WeightHistoryCacheTest {

    private lateinit var cache: WeightHistoryCache
    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    @Before
    fun setup() {
        cache = WeightHistoryCache()
    }

    // ==================== BASIC OPERATIONS ====================

    @Test
    fun newCache_isEmpty() {
        assertTrue(cache.isEmpty())
        assertEquals(0, cache.size)
    }

    @Test
    fun put_addsEntry() {
        val entry = createEntry(1, 200.0, System.currentTimeMillis())
        cache.put(entry)

        assertEquals(1, cache.size)
        assertFalse(cache.isEmpty())
    }

    @Test
    fun put_updatesExistingDateEntry() {
        val timestamp = System.currentTimeMillis()
        val entry1 = createEntry(1, 200.0, timestamp)
        val entry2 = createEntry(2, 195.0, timestamp) // Same date, different weight

        cache.put(entry1)
        cache.put(entry2)

        // Should still be 1 entry (updated, not added)
        assertEquals(1, cache.size)

        // Should have the updated weight
        val dateKey = dateFormatter.format(timestamp)
        assertEquals(195.0, cache.getByDate(dateKey)?.weight ?: 0.0, 0.01)
    }

    // ==================== O(1) LOOKUP TESTS ====================

    @Test
    fun getByDate_returnsCorrectEntry() {
        val timestamp = System.currentTimeMillis()
        val entry = createEntry(1, 200.0, timestamp)
        cache.put(entry)

        val dateKey = dateFormatter.format(timestamp)
        val result = cache.getByDate(dateKey)

        assertNotNull(result)
        assertEquals(200.0, result!!.weight, 0.01)
    }

    @Test
    fun getByDate_returnsNullForMissingDate() {
        val result = cache.getByDate("2099-12-31")
        assertNull(result)
    }

    @Test
    fun getByIndex_returnsCorrectEntry() {
        val baseTime = System.currentTimeMillis()

        // Add entries in random order
        cache.put(createEntry(2, 198.0, baseTime + 86400000L)) // Day 2
        cache.put(createEntry(1, 200.0, baseTime)) // Day 1
        cache.put(createEntry(3, 196.0, baseTime + 172800000L)) // Day 3

        // Index 0 should be oldest (Day 1)
        assertEquals(200.0, cache.getByIndex(0)?.weight ?: 0.0, 0.01)

        // Index 2 should be newest (Day 3)
        assertEquals(196.0, cache.getByIndex(2)?.weight ?: 0.0, 0.01)
    }

    @Test
    fun getByIndex_returnsNullForInvalidIndex() {
        assertNull(cache.getByIndex(0))
        assertNull(cache.getByIndex(-1))
        assertNull(cache.getByIndex(100))
    }

    // ==================== SORTED ORDER TESTS ====================

    @Test
    fun entries_maintainsSortedOrder() {
        val baseTime = System.currentTimeMillis()

        // Add entries out of order
        cache.put(createEntry(3, 196.0, baseTime + 172800000L)) // Day 3
        cache.put(createEntry(1, 200.0, baseTime)) // Day 1
        cache.put(createEntry(2, 198.0, baseTime + 86400000L)) // Day 2

        val sorted = cache.getAllSorted()

        assertEquals(3, sorted.size)
        assertEquals(200.0, sorted[0].weight, 0.01) // Oldest first
        assertEquals(198.0, sorted[1].weight, 0.01)
        assertEquals(196.0, sorted[2].weight, 0.01) // Newest last
    }

    @Test
    fun getLatest_returnsNewestEntry() {
        val baseTime = System.currentTimeMillis()

        cache.put(createEntry(1, 200.0, baseTime))
        cache.put(createEntry(2, 195.0, baseTime + 86400000L))

        val latest = cache.getLatest()

        assertNotNull(latest)
        assertEquals(195.0, latest!!.weight, 0.01)
    }

    @Test
    fun getOldest_returnsOldestEntry() {
        val baseTime = System.currentTimeMillis()

        cache.put(createEntry(2, 195.0, baseTime + 86400000L))
        cache.put(createEntry(1, 200.0, baseTime))

        val oldest = cache.getOldest()

        assertNotNull(oldest)
        assertEquals(200.0, oldest!!.weight, 0.01)
    }

    // ==================== RANGE QUERY TESTS ====================

    @Test
    fun getLastN_returnsCorrectEntries() {
        val baseTime = System.currentTimeMillis()

        for (i in 0..9) {
            cache.put(createEntry(i + 1, 200.0 - i, baseTime + (i * 86400000L)))
        }

        val last3 = cache.getLastN(3)

        assertEquals(3, last3.size)
        assertEquals(193.0, last3[0].weight, 0.01) // 3rd from last
        assertEquals(192.0, last3[1].weight, 0.01) // 2nd from last
        assertEquals(191.0, last3[2].weight, 0.01) // Last
    }

    @Test
    fun getEntriesInRange_returnsCorrectEntries() {
        val baseTime = System.currentTimeMillis()

        for (i in 0..9) {
            cache.put(createEntry(i + 1, 200.0 - i, baseTime + (i * 86400000L)))
        }

        // Get entries from day 3 to day 6
        val startTime = baseTime + (3 * 86400000L)
        val endTime = baseTime + (6 * 86400000L)

        val range = cache.getEntriesInRange(startTime, endTime)

        assertEquals(4, range.size) // Days 3, 4, 5, 6
    }

    // ==================== BULK OPERATIONS ====================

    @Test
    fun loadAll_loadsAndSortsEntries() {
        val baseTime = System.currentTimeMillis()

        val entries = listOf(
            createEntry(3, 196.0, baseTime + 172800000L),
            createEntry(1, 200.0, baseTime),
            createEntry(2, 198.0, baseTime + 86400000L)
        )

        cache.loadAll(entries)

        assertEquals(3, cache.size)

        val sorted = cache.getAllSorted()
        assertEquals(200.0, sorted[0].weight, 0.01) // Oldest
        assertEquals(196.0, sorted[2].weight, 0.01) // Newest
    }

    @Test
    fun clear_removesAllEntries() {
        cache.put(createEntry(1, 200.0, System.currentTimeMillis()))
        cache.put(createEntry(2, 198.0, System.currentTimeMillis() + 86400000L))

        cache.clear()

        assertTrue(cache.isEmpty())
        assertEquals(0, cache.size)
    }

    // ==================== HELPER FUNCTION ====================

    private fun createEntry(id: Int, weight: Double, timestamp: Long): WeightEntry {
        return WeightEntry(
            entryId = id,
            userId = 1,
            weight = weight,
            timestamp = timestamp
        )
    }
}