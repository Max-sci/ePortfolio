package com.example.weight_trackingapp.ui.analytics

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weight_trackingapp.algorithms.WeightHistoryCache
import com.example.weight_trackingapp.algorithms.WeightStatistics
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.data.repository.WeightRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * ViewModel for Analytics screen.
 *
 * Demonstrates use of algorithms:
 * - Moving Average for trend smoothing
 * - Linear Regression for predictions
 * - Binary Search for efficient lookups
 * - Custom WeightHistoryCache data structure
 */
class AnalyticsViewModel(
    private val repository: WeightRepository,
    private val userId: Int
) : ViewModel() {

    // ==================== DATA STRUCTURES ====================

    // Custom cache data structure for O(1) lookups
    private val weightCache = WeightHistoryCache()

    // ==================== UI STATE ====================

    data class AnalyticsState(
        val entries: List<WeightEntry> = emptyList(),
        val movingAverages: List<Double> = emptyList(),
        val statistics: WeightStatistics.StatisticsResult? = null,
        val regression: WeightStatistics.RegressionResult? = null,
        val predictedWeight7Days: Double? = null,
        val predictedWeight30Days: Double? = null,
        val daysToGoal: Int? = null,
        val weeklyRate: Double? = null,
        val goalWeight: Double? = null,
        val isLoading: Boolean = false,
        val errorMessage: String? = null
    )

    private val _analyticsState = MutableLiveData(AnalyticsState())
    val analyticsState: LiveData<AnalyticsState> = _analyticsState

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    // Store goal weight for predictions
    private var goalWeight: Double? = null

    // ==================== INITIALIZATION ====================

    init {
        loadAnalytics()
    }

    /**
     * Loads all analytics data using the implemented algorithms.
     */
    fun loadAnalytics() {
        _isLoading.value = true

        viewModelScope.launch {
            try {
                // Get goal weight FIRST
                val goal = repository.getGoalWeight(userId)
                goalWeight = goal?.goalWeight

                // Get all weight entries from repository
                val weightEntries = repository.observeWeightEntries(userId).first()

                if (weightEntries.isNotEmpty()) {
                    processAnalytics(weightEntries.sortedBy { it.timestamp })
                } else {
                    _analyticsState.value = AnalyticsState(
                        errorMessage = "No weight entries found. Add some entries first!",
                        goalWeight = goalWeight
                    )
                }
                _isLoading.value = false
            } catch (e: Exception) {
                _analyticsState.value = AnalyticsState(
                    errorMessage = "Error loading analytics: ${e.message}",
                    goalWeight = goalWeight
                )
                _isLoading.value = false
            }
        }
    }

    /**
     * Processes all analytics algorithms on the weight data.
     */
    private fun processAnalytics(entries: List<WeightEntry>) {
        // Load data into custom cache structure
        weightCache.loadAll(entries)

        // 1. Calculate Moving Average - O(n)
        val movingAverages = WeightStatistics.calculateMovingAverage(entries)

        // 2. Calculate Statistics - O(n)
        val statistics = WeightStatistics.calculateStatistics(entries)

        // 3. Calculate Linear Regression - O(n)
        val regression = WeightStatistics.calculateLinearRegression(entries)

        // 4. Make Predictions using regression
        var predicted7Days: Double? = null
        var predicted30Days: Double? = null
        var daysToGoal: Int? = null

        if (regression != null) {
            predicted7Days = WeightStatistics.predictWeight(
                regression, entries.size, 7
            )
            predicted30Days = WeightStatistics.predictWeight(
                regression, entries.size, 30
            )

            // Calculate days to goal if goal is set
            goalWeight?.let { goal ->
                daysToGoal = WeightStatistics.estimateDaysToGoal(
                    regression, entries.size, goal
                )
            }
        }

        // 5. Calculate weekly rate of change
        val weeklyRate = WeightStatistics.calculateWeeklyRate(entries)

        // Update state
        _analyticsState.value = AnalyticsState(
            entries = entries,
            movingAverages = movingAverages,
            statistics = statistics,
            regression = regression,
            predictedWeight7Days = predicted7Days,
            predictedWeight30Days = predicted30Days,
            daysToGoal = daysToGoal,
            weeklyRate = weeklyRate,
            goalWeight = goalWeight,
            isLoading = false
        )
    }

    /**
     * Demonstrates binary search - finds entry closest to a date.
     *
     * TIME COMPLEXITY: O(log n) vs O(n) for linear search
     */
    fun findEntryByDate(timestamp: Long): WeightEntry? {
        val entries = weightCache.getAllSorted()
        val index = WeightStatistics.binarySearchClosest(entries, timestamp)
        return if (index >= 0) entries[index] else null
    }

    /**
     * Gets entries for a specific date range using binary search.
     *
     * TIME COMPLEXITY: O(log n + k)
     */
    fun getEntriesInRange(startTimestamp: Long, endTimestamp: Long): List<WeightEntry> {
        return weightCache.getEntriesInRange(startTimestamp, endTimestamp)
    }

    /**
     * Gets the latest N entries from cache.
     *
     * TIME COMPLEXITY: O(n) where n is count
     */
    fun getRecentEntries(count: Int): List<WeightEntry> {
        return weightCache.getLastN(count)
    }

    /**
     * Demonstrates O(1) lookup by date using HashMap.
     */
    fun getEntryForDate(dateString: String): WeightEntry? {
        return weightCache.getByDate(dateString)
    }

    /**
     * Refreshes analytics data.
     */
    fun refresh() {
        loadAnalytics()
    }
}