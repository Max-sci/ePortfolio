package com.example.weight_trackingapp.ui.settings

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.remote.CloudRepository
import com.example.weight_trackingapp.data.remote.WeightEntryRequest
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.launch

/**
 * CloudSyncActivity - Manages cloud database synchronization
 *
 * FEATURES:
 * - Register/Login to cloud
 * - Sync local data to MongoDB Atlas
 * - View cloud statistics
 *
 * COURSE OUTCOME: Cloud database integration with offline-first architecture
 */
class CloudSyncActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager
    private lateinit var localRepository: WeightRepository
    private lateinit var cloudRepository: CloudRepository

    // Views
    private lateinit var toolbar: MaterialToolbar
    private lateinit var tvCloudStatus: TextView
    private lateinit var tvSyncInfo: TextView
    private lateinit var btnConnectCloud: MaterialButton
    private lateinit var btnSyncToCloud: MaterialButton
    private lateinit var btnViewCloudStats: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var cardCloudStats: MaterialCardView
    private lateinit var tvCloudStats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cloud_sync)

        sessionManager = SecureSessionManager(this)
        cloudRepository = CloudRepository()

        val database = AppDatabase.getInstance(applicationContext)
        localRepository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )

        initializeViews()
        setupToolbar()
        setupClickListeners()
        updateUI()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        tvCloudStatus = findViewById(R.id.tvCloudStatus)
        tvSyncInfo = findViewById(R.id.tvSyncInfo)
        btnConnectCloud = findViewById(R.id.btnConnectCloud)
        btnSyncToCloud = findViewById(R.id.btnSyncToCloud)
        btnViewCloudStats = findViewById(R.id.btnViewCloudStats)
        progressBar = findViewById(R.id.progressBar)
        cardCloudStats = findViewById(R.id.cardCloudStats)
        tvCloudStats = findViewById(R.id.tvCloudStats)
    }

    private fun setupToolbar() {
        toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupClickListeners() {
        btnConnectCloud.setOnClickListener {
            connectToCloud()
        }

        btnSyncToCloud.setOnClickListener {
            syncToCloud()
        }

        btnViewCloudStats.setOnClickListener {
            viewCloudStats()
        }
    }

    private fun updateUI() {
        if (sessionManager.isCloudSynced()) {
            tvCloudStatus.text = "✅ Connected to Cloud"
            tvCloudStatus.setTextColor(getColor(android.R.color.holo_green_dark))
            btnConnectCloud.text = "Reconnect to Cloud"
            btnSyncToCloud.isEnabled = true
            btnViewCloudStats.isEnabled = true
        } else {
            tvCloudStatus.text = "❌ Not Connected"
            tvCloudStatus.setTextColor(getColor(android.R.color.holo_red_dark))
            btnConnectCloud.text = "Connect to Cloud"
            btnSyncToCloud.isEnabled = false
            btnViewCloudStats.isEnabled = false
        }
    }

    private fun connectToCloud() {
        val username = sessionManager.getUsername() ?: return

        showLoading(true)

        lifecycleScope.launch {
            // Try to register first, if fails then login
            var result = cloudRepository.register(username, "password123")

            if (result is CloudRepository.CloudResult.Error) {
                // User might already exist, try login
                result = cloudRepository.login(username, "password123")
            }

            when (result) {
                is CloudRepository.CloudResult.Success -> {
                    val token = result.data.token
                    val cloudUserId = result.data.user?.id

                    if (token != null && cloudUserId != null) {
                        sessionManager.saveCloudCredentials(token, cloudUserId)
                        showToast("Connected to cloud successfully!")
                        updateUI()
                    } else {
                        showToast("Connection failed: Invalid response")
                    }
                }
                is CloudRepository.CloudResult.Error -> {
                    showToast("Connection failed: ${result.message}")
                }
            }

            showLoading(false)
        }
    }

    private fun syncToCloud() {
        val token = sessionManager.getJwtToken() ?: return
        val userId = sessionManager.getUserId()

        showLoading(true)
        tvSyncInfo.text = "Syncing..."

        lifecycleScope.launch {
            try {
                // Get all local entries
                val localEntries = localRepository.getAllEntriesForExport(userId)

                if (localEntries.isEmpty()) {
                    showToast("No entries to sync")
                    showLoading(false)
                    return@launch
                }

                // Convert to API format
                val syncEntries = localEntries.map { entry ->
                    WeightEntryRequest(
                        weight = entry.weight,
                        timestamp = entry.timestamp,
                        notes = null
                    )
                }

                // Sync to cloud
                val result = cloudRepository.syncEntries(token, syncEntries)

                when (result) {
                    is CloudRepository.CloudResult.Success -> {
                        val created = result.data.created ?: result.data.results?.created ?: 0
                        tvSyncInfo.text = "Last sync: Now\nEntries synced: $created"
                        showToast("Synced $created entries to cloud!")
                    }
                    is CloudRepository.CloudResult.Error -> {
                        tvSyncInfo.text = "Sync failed"
                        showToast("Sync failed: ${result.message}")
                    }
                }
            } catch (e: Exception) {
                tvSyncInfo.text = "Sync error"
                showToast("Error: ${e.message}")
            }

            showLoading(false)
        }
    }

    private fun viewCloudStats() {
        val token = sessionManager.getJwtToken() ?: return

        showLoading(true)
        cardCloudStats.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = cloudRepository.getStatsSummary(token)

            when (result) {
                is CloudRepository.CloudResult.Success -> {
                    val stats = result.data
                    tvCloudStats.text = buildString {
                        appendLine("📊 Cloud Statistics")
                        appendLine("─────────────────")
                        appendLine("Total Entries: ${stats.totalEntries}")
                        stats.averageWeight?.let { appendLine("Average Weight: %.1f lbs".format(it)) }
                        stats.minWeight?.let { appendLine("Lowest Weight: %.1f lbs".format(it)) }
                        stats.maxWeight?.let { appendLine("Highest Weight: %.1f lbs".format(it)) }
                        stats.weightRange?.let { appendLine("Weight Range: %.1f lbs".format(it)) }
                    }
                }
                is CloudRepository.CloudResult.Error -> {
                    tvCloudStats.text = "Failed to load stats: ${result.message}"
                }
            }

            showLoading(false)
        }
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        btnConnectCloud.isEnabled = !show
        btnSyncToCloud.isEnabled = !show && sessionManager.isCloudSynced()
        btnViewCloudStats.isEnabled = !show && sessionManager.isCloudSynced()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}