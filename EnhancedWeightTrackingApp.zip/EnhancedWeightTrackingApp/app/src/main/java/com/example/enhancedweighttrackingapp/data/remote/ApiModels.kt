package com.example.weight_trackingapp.data.remote

import com.google.gson.annotations.SerializedName

/**
 * API Response Models
 *
 * Data classes for parsing JSON responses from the backend API
 *
 * COURSE OUTCOME: RESTful API integration
 */

// ==================== AUTH MODELS ====================

data class RegisterRequest(
    val username: String,
    val password: String
)

data class LoginRequest(
    val username: String,
    val password: String
)

data class AuthResponse(
    val message: String,
    val token: String?,
    val user: UserResponse?,
    val error: String?
)

data class UserResponse(
    val id: String,
    val username: String
)

// ==================== WEIGHT ENTRY MODELS ====================

data class WeightEntryRequest(
    val weight: Double,
    val timestamp: Long?,
    val notes: String?
)

data class WeightEntryResponse(
    @SerializedName("_id")
    val id: String,
    val userId: String,
    val weight: Double,
    val timestamp: String,
    val notes: String?,
    val syncStatus: String?
)

data class WeightEntriesResponse(
    val entries: List<WeightEntryResponse>
)

data class CreateEntryResponse(
    val message: String,
    val entry: WeightEntryResponse?
)

data class DeleteResponse(
    val message: String
)

// ==================== SYNC MODELS ====================

data class SyncRequest(
    val entries: List<WeightEntryRequest>
)

data class SyncResponse(
    val message: String,
    val created: Int?,
    val results: SyncResults?
)

data class SyncResults(
    val created: Int,
    val updated: Int,
    val failed: Int
)

// ==================== GOAL MODELS ====================

data class GoalRequest(
    val goalWeight: Double,
    val startingWeight: Double
)

data class GoalResponse(
    @SerializedName("_id")
    val id: String?,
    val userId: String?,
    val goalWeight: Double,
    val startingWeight: Double,
    val isAchieved: Boolean?,
    val message: String?
)

// ==================== STATS MODELS ====================

data class StatsSummaryResponse(
    val totalEntries: Int,
    val averageWeight: Double?,
    val minWeight: Double?,
    val maxWeight: Double?,
    val weightRange: Double?,
    val firstEntry: String?,
    val lastEntry: String?
)

data class WeeklyStatsResponse(
    val year: Int,
    val week: Int,
    val averageWeight: Double,
    val minWeight: Double,
    val maxWeight: Double,
    val entryCount: Int,
    val startDate: String?,
    val endDate: String?
)

data class MonthlyStatsResponse(
    val year: Int,
    val month: Int,
    val averageWeight: Double,
    val minWeight: Double,
    val maxWeight: Double,
    val entryCount: Int,
    val weightChange: Double?,
    val startDate: String?,
    val endDate: String?
)

data class TrendResponse(
    val trend: String,
    val totalChange: Double?,
    val weeklyRate: Double?,
    val firstWeight: Double?,
    val lastWeight: Double?,
    val totalEntries: Int?,
    val message: String?
)