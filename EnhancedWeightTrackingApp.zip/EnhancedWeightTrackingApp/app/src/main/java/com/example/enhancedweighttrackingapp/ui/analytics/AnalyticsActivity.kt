package com.example.weight_trackingapp.ui.analytics

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.appbar.MaterialToolbar
import java.util.Locale

/**
 * Analytics Activity - Displays weight analysis using algorithms.
 *
 * DEMONSTRATES:
 * - Moving Average Algorithm
 * - Linear Regression Predictions
 * - Statistical Analysis
 * - Custom Data Structure usage
 */
class AnalyticsActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager

    // Views
    private lateinit var toolbar: MaterialToolbar
    private lateinit var progressBar: ProgressBar
    private lateinit var tvCurrentWeight: TextView
    private lateinit var tvAverageWeight: TextView
    private lateinit var tvMinWeight: TextView
    private lateinit var tvMaxWeight: TextView
    private lateinit var tvStdDev: TextView
    private lateinit var tvEntryCount: TextView
    private lateinit var tvWeeklyRate: TextView
    private lateinit var tvTrend: TextView
    private lateinit var tvPrediction7Days: TextView
    private lateinit var tvPrediction30Days: TextView
    private lateinit var tvDaysToGoal: TextView
    private lateinit var tvRSquared: TextView
    private lateinit var tvMovingAverage: TextView
    private lateinit var tvErrorMessage: TextView

    // ViewModel
    private val viewModel: AnalyticsViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        val repository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )
        AnalyticsViewModelFactory(repository, sessionManager.getUserId())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analytics)

        sessionManager = SecureSessionManager(this)

        initializeViews()
        setupToolbar()
        observeViewModel()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        progressBar = findViewById(R.id.progressBar)
        tvCurrentWeight = findViewById(R.id.tvCurrentWeight)
        tvAverageWeight = findViewById(R.id.tvAverageWeight)
        tvMinWeight = findViewById(R.id.tvMinWeight)
        tvMaxWeight = findViewById(R.id.tvMaxWeight)
        tvStdDev = findViewById(R.id.tvStdDev)
        tvEntryCount = findViewById(R.id.tvEntryCount)
        tvWeeklyRate = findViewById(R.id.tvWeeklyRate)
        tvTrend = findViewById(R.id.tvTrend)
        tvPrediction7Days = findViewById(R.id.tvPrediction7Days)
        tvPrediction30Days = findViewById(R.id.tvPrediction30Days)
        tvDaysToGoal = findViewById(R.id.tvDaysToGoal)
        tvRSquared = findViewById(R.id.tvRSquared)
        tvMovingAverage = findViewById(R.id.tvMovingAverage)
        tvErrorMessage = findViewById(R.id.tvErrorMessage)
    }

    private fun setupToolbar() {
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(this) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.analyticsState.observe(this) { state ->
            if (state.errorMessage != null) {
                tvErrorMessage.text = state.errorMessage
                tvErrorMessage.visibility = View.VISIBLE
            } else {
                tvErrorMessage.visibility = View.GONE
                updateUI(state)
            }
        }
    }

    private fun updateUI(state: AnalyticsViewModel.AnalyticsState) {
        // Current weight (latest entry)
        val latestWeight = state.entries.lastOrNull()?.weight
        tvCurrentWeight.text = latestWeight?.let {
            String.format(Locale.getDefault(), "%.1f lbs", it)
        } ?: "--"

        // Statistics
        state.statistics?.let { stats ->
            tvAverageWeight.text = String.format(Locale.getDefault(), "%.1f lbs", stats.mean)
            tvMinWeight.text = String.format(Locale.getDefault(), "%.1f lbs", stats.min)
            tvMaxWeight.text = String.format(Locale.getDefault(), "%.1f lbs", stats.max)
            tvStdDev.text = String.format(Locale.getDefault(), "±%.2f lbs", stats.standardDeviation)
            tvEntryCount.text = stats.count.toString()
        }

        // Weekly rate of change
        state.weeklyRate?.let { rate ->
            val rateText = if (rate < 0) {
                String.format(Locale.getDefault(), "%.2f lbs/week (losing)", rate)
            } else if (rate > 0) {
                String.format(Locale.getDefault(), "+%.2f lbs/week (gaining)", rate)
            } else {
                "0.00 lbs/week (maintaining)"
            }
            tvWeeklyRate.text = rateText

            // Trend indicator
            tvTrend.text = when {
                rate < -1.0 -> "📉 Losing weight quickly"
                rate < 0 -> "📉 Losing weight"
                rate > 1.0 -> "📈 Gaining weight quickly"
                rate > 0 -> "📈 Gaining weight"
                else -> "➡️ Maintaining weight"
            }
        }

        // Regression results
        state.regression?.let { regression ->
            tvRSquared.text = String.format(Locale.getDefault(), "%.3f", regression.rSquared)
        }

        // Predictions
        state.predictedWeight7Days?.let { prediction ->
            tvPrediction7Days.text = String.format(Locale.getDefault(), "%.1f lbs", prediction)
        } ?: run { tvPrediction7Days.text = "--" }

        state.predictedWeight30Days?.let { prediction ->
            tvPrediction30Days.text = String.format(Locale.getDefault(), "%.1f lbs", prediction)
        } ?: run { tvPrediction30Days.text = "--" }

        // Days to goal
        when {
            state.goalWeight == null -> {
                tvDaysToGoal.text = "Set a goal to see estimate"
            }
            state.daysToGoal != null -> {
                tvDaysToGoal.text = "${state.daysToGoal} days"
            }
            else -> {
                tvDaysToGoal.text = "Goal reached or trend unchanged"
            }
        }

        // Moving average (latest value)
        val latestMovingAvg = state.movingAverages.lastOrNull()
        tvMovingAverage.text = latestMovingAvg?.let {
            String.format(Locale.getDefault(), "%.1f lbs", it)
        } ?: "--"
    }
}