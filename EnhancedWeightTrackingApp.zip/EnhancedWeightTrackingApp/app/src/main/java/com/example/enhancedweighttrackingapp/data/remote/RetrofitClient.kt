package com.example.weight_trackingapp.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Retrofit Client - Singleton for API access
 *
 * Configures the HTTP client and Retrofit instance
 * Connects to the Node.js/Express backend
 *
 * COURSE OUTCOME: RESTful API integration
 */
object RetrofitClient {

    // For Android Emulator, use 10.0.2.2 to access localhost
    // For physical device on same WiFi, use your computer's IP address
    private const val BASE_URL = "http://10.0.2.2:3000/"

    // Logging interceptor for debugging
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    // OkHttp client with timeouts and logging
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // Retrofit instance
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    // API Service instance
    val apiService: ApiService = retrofit.create(ApiService::class.java)

    /**
     * Helper function to format the auth token
     */
    fun bearerToken(token: String): String {
        return "Bearer $token"
    }
}