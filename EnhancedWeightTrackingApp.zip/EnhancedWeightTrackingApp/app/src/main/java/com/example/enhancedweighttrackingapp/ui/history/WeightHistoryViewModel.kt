package com.example.weight_trackingapp.ui.history

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.data.repository.WeightRepository
import kotlinx.coroutines.launch

/**
 * ViewModel for Weight History screen.
 *
 * HANDLES:
 * - Loading weight entries
 * - Adding new entries
 * - Deleting entries
 */
class WeightHistoryViewModel(
    private val repository: WeightRepository,
    private val userId: Int
) : ViewModel() {

    // ==================== UI STATE ====================

    sealed class AddEntryResult {
        object Success : AddEntryResult()
        data class Error(val message: String) : AddEntryResult()
    }

    private val _addEntryResult = MutableLiveData<AddEntryResult?>()
    val addEntryResult: LiveData<AddEntryResult?> = _addEntryResult

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    // Reactive list of weight entries
    val weightEntries: LiveData<List<WeightEntry>> =
        repository.observeWeightEntries(userId).asLiveData()

    // ==================== USER ACTIONS ====================

    /**
     * Adds a new weight entry.
     */
    fun addWeightEntry(weightStr: String, notes: String? = null) {
        // Validate weight
        val weight = weightStr.toDoubleOrNull()
        if (weight == null) {
            _addEntryResult.value = AddEntryResult.Error("Please enter a valid number")
            return
        }

        if (weight <= 0 || weight > 1000) {
            _addEntryResult.value = AddEntryResult.Error("Please enter a valid weight (1-1000 lbs)")
            return
        }

        _isLoading.value = true

        viewModelScope.launch {
            try {
                val entryId = repository.addWeightEntry(userId, weight, notes)
                if (entryId > 0) {
                    _addEntryResult.value = AddEntryResult.Success
                } else {
                    _addEntryResult.value = AddEntryResult.Error("Failed to add entry")
                }
            } catch (e: Exception) {
                _addEntryResult.value = AddEntryResult.Error("Error: ${e.message}")
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Deletes a weight entry.
     */
    fun deleteWeightEntry(entry: WeightEntry) {
        viewModelScope.launch {
            repository.deleteWeightEntry(entry)
        }
    }

    /**
     * Clears the add entry result.
     */
    fun clearAddEntryResult() {
        _addEntryResult.value = null
    }
}