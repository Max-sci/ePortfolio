package com.example.weight_trackingapp.algorithms

import com.example.weight_trackingapp.data.local.entity.WeightEntry
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Custom Data Structure: WeightHistoryCache
 *
 * DESIGN: Combines HashMap and sorted ArrayList for optimal performance
 * - HashMap: O(1) lookup by date string
 * - ArrayList: O(1) access by index, maintains chronological order
 *
 * TRADE-OFF ANALYSIS:
 * - Space: O(2n) - stores references in both structures
 * - Time: O(1) for lookups, O(n) for insertion (maintaining sort)
 * - Benefit: Fast date-based queries AND ordered iteration
 *
 * COURSE OUTCOME 3: Managing trade-offs in design choices
 */
class WeightHistoryCache {

    // HashMap for O(1) date string lookup
    private val dateMap: HashMap<String, WeightEntry> = HashMap()

    // Sorted ArrayList for maintaining chronological order
    private val sortedEntries: ArrayList<WeightEntry> = ArrayList()

    // Date formatter for consistent key generation
    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    /**
     * Returns the number of entries in the cache.
     * TIME COMPLEXITY: O(1)
     */
    val size: Int
        get() = sortedEntries.size

    /**
     * Checks if the cache is empty.
     * TIME COMPLEXITY: O(1)
     */
    fun isEmpty(): Boolean = sortedEntries.isEmpty()

    /**
     * Adds or updates a weight entry in the cache.
     *
     * TIME COMPLEXITY: O(n) for insertion to maintain sort order
     * SPACE COMPLEXITY: O(1) additional space
     *
     * @param entry The weight entry to add
     */
    fun put(entry: WeightEntry) {
        val dateKey = dateFormatter.format(entry.timestamp)

        // Check if entry for this date already exists
        val existingEntry = dateMap[dateKey]

        if (existingEntry != null) {
            // Update existing entry - remove old, add new
            sortedEntries.remove(existingEntry)
        }

        // Add to HashMap for O(1) lookup
        dateMap[dateKey] = entry

        // Insert into sorted position in ArrayList
        insertSorted(entry)
    }

    /**
     * Inserts entry in sorted position (by timestamp).
     * Uses binary search to find insertion point.
     *
     * TIME COMPLEXITY: O(log n) for search + O(n) for insertion = O(n)
     */
    private fun insertSorted(entry: WeightEntry) {
        if (sortedEntries.isEmpty()) {
            sortedEntries.add(entry)
            return
        }

        // Binary search for insertion point
        var left = 0
        var right = sortedEntries.size

        while (left < right) {
            val mid = left + (right - left) / 2
            if (sortedEntries[mid].timestamp < entry.timestamp) {
                left = mid + 1
            } else {
                right = mid
            }
        }

        sortedEntries.add(left, entry)
    }

    /**
     * Gets a weight entry by date string.
     *
     * TIME COMPLEXITY: O(1) - HashMap lookup
     *
     * @param dateString Date in "yyyy-MM-dd" format
     * @return WeightEntry or null if not found
     */
    fun getByDate(dateString: String): WeightEntry? {
        return dateMap[dateString]
    }

    /**
     * Gets a weight entry by timestamp.
     *
     * TIME COMPLEXITY: O(1) - converts to date string and uses HashMap
     *
     * @param timestamp Unix timestamp in milliseconds
     * @return WeightEntry or null if not found
     */
    fun getByTimestamp(timestamp: Long): WeightEntry? {
        val dateKey = dateFormatter.format(timestamp)
        return dateMap[dateKey]
    }

    /**
     * Gets entry by index in chronological order.
     *
     * TIME COMPLEXITY: O(1) - ArrayList index access
     *
     * @param index Position in sorted list (0 = oldest)
     * @return WeightEntry at that position
     */
    fun getByIndex(index: Int): WeightEntry? {
        return if (index in 0 until sortedEntries.size) {
            sortedEntries[index]
        } else {
            null
        }
    }

    /**
     * Gets the most recent weight entry.
     *
     * TIME COMPLEXITY: O(1)
     */
    fun getLatest(): WeightEntry? {
        return sortedEntries.lastOrNull()
    }

    /**
     * Gets the oldest weight entry.
     *
     * TIME COMPLEXITY: O(1)
     */
    fun getOldest(): WeightEntry? {
        return sortedEntries.firstOrNull()
    }

    /**
     * Checks if an entry exists for a given date.
     *
     * TIME COMPLEXITY: O(1) - HashMap containsKey
     *
     * @param dateString Date in "yyyy-MM-dd" format
     * @return true if entry exists
     */
    fun containsDate(dateString: String): Boolean {
        return dateMap.containsKey(dateString)
    }

    /**
     * Removes an entry by date.
     *
     * TIME COMPLEXITY: O(n) - need to find and remove from ArrayList
     *
     * @param dateString Date in "yyyy-MM-dd" format
     * @return The removed entry, or null if not found
     */
    fun remove(dateString: String): WeightEntry? {
        val entry = dateMap.remove(dateString)
        if (entry != null) {
            sortedEntries.remove(entry)
        }
        return entry
    }

    /**
     * Gets all entries in chronological order (oldest first).
     *
     * TIME COMPLEXITY: O(n) - creates a copy of the list
     *
     * @return List of all entries sorted by date
     */
    fun getAllSorted(): List<WeightEntry> {
        return sortedEntries.toList()
    }

    /**
     * Gets all entries in reverse chronological order (newest first).
     *
     * TIME COMPLEXITY: O(n)
     *
     * @return List of all entries, newest first
     */
    fun getAllReversed(): List<WeightEntry> {
        return sortedEntries.reversed()
    }

    /**
     * Gets the last N entries (most recent).
     *
     * TIME COMPLEXITY: O(n) where n is the requested count
     *
     * @param count Number of entries to retrieve
     * @return List of most recent entries
     */
    fun getLastN(count: Int): List<WeightEntry> {
        val startIndex = maxOf(0, sortedEntries.size - count)
        return sortedEntries.subList(startIndex, sortedEntries.size).toList()
    }

    /**
     * Gets entries within a date range using binary search.
     *
     * TIME COMPLEXITY: O(log n + k) where k is the number of results
     *
     * @param startTimestamp Start of range (inclusive)
     * @param endTimestamp End of range (inclusive)
     * @return List of entries within range
     */
    fun getEntriesInRange(startTimestamp: Long, endTimestamp: Long): List<WeightEntry> {
        return WeightStatistics.findEntriesInRange(sortedEntries, startTimestamp, endTimestamp)
    }

    /**
     * Clears all entries from the cache.
     *
     * TIME COMPLEXITY: O(1)
     */
    fun clear() {
        dateMap.clear()
        sortedEntries.clear()
    }

    /**
     * Loads multiple entries efficiently.
     *
     * TIME COMPLEXITY: O(n log n) - sorts once after adding all
     * More efficient than calling put() n times which would be O(n²)
     *
     * @param entries List of weight entries to load
     */
    fun loadAll(entries: List<WeightEntry>) {
        clear()

        // Add all to HashMap
        for (entry in entries) {
            val dateKey = dateFormatter.format(entry.timestamp)
            dateMap[dateKey] = entry
        }

        // Add all to ArrayList and sort once
        sortedEntries.addAll(entries)
        sortedEntries.sortBy { it.timestamp }
    }

    /**
     * Returns cache statistics for debugging/analysis.
     */
    fun getStats(): String {
        return """
            Cache Statistics:
            - Total entries: $size
            - HashMap size: ${dateMap.size}
            - ArrayList size: ${sortedEntries.size}
            - Date range: ${getOldest()?.timestamp} to ${getLatest()?.timestamp}
        """.trimIndent()
    }
}