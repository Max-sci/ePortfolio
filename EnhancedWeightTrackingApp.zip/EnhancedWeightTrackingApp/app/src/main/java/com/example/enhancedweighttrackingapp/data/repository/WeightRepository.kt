package com.example.weight_trackingapp.data.repository

import com.example.weight_trackingapp.data.local.dao.GoalWeightDao
import com.example.weight_trackingapp.data.local.dao.UserDao
import com.example.weight_trackingapp.data.local.dao.WeightEntryDao
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import com.example.weight_trackingapp.data.local.entity.User
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.util.SecurityUtils
import kotlinx.coroutines.flow.Flow

/**
 * Repository - Single source of truth for all data.
 *
 * MVVM ARCHITECTURE:
 * - ViewModels talk to Repository (not directly to database)
 * - Handles business logic (password hashing, validation)
 * - Could easily add remote data source later
 *
 * COURSE OUTCOME 4: Use well-founded techniques for database operations
 */
class WeightRepository(
    private val userDao: UserDao,
    private val weightEntryDao: WeightEntryDao,
    private val goalWeightDao: GoalWeightDao
) {

    // ==================== AUTH RESULTS ====================

    sealed class AuthResult {
        data class Success(val userId: Int, val username: String) : AuthResult()
        data class Error(val message: String) : AuthResult()
        object AccountLocked : AuthResult()
    }

    // ==================== USER OPERATIONS ====================

    /**
     * Registers a new user with secure password hashing.
     */
    suspend fun registerUser(username: String, password: String): AuthResult {
        // Validate username
        val usernameCheck = SecurityUtils.validateUsername(username)
        if (!usernameCheck.isValid) {
            return AuthResult.Error(usernameCheck.errorMessage)
        }

        // Validate password
        val passwordCheck = SecurityUtils.validatePassword(password)
        if (!passwordCheck.isValid) {
            return AuthResult.Error(passwordCheck.errorMessage)
        }

        // Check if username exists
        if (userDao.checkUserExists(username) > 0) {
            return AuthResult.Error("Username already exists")
        }

        // Hash password and create user
        val passwordHash = SecurityUtils.hashPassword(password)
        val user = User(
            username = SecurityUtils.sanitizeInput(username),
            passwordHash = passwordHash
        )

        return try {
            val userId = userDao.insertUser(user)
            AuthResult.Success(userId.toInt(), username)
        } catch (e: Exception) {
            AuthResult.Error("Registration failed")
        }
    }

    /**
     * Logs in a user with secure password verification.
     */
    suspend fun loginUser(username: String, password: String): AuthResult {
        val user = userDao.getUserByUsername(SecurityUtils.sanitizeInput(username))
            ?: return AuthResult.Error("Invalid username or password")

        // Check if account is locked
        if (user.isLocked) {
            return AuthResult.AccountLocked
        }

        // Verify password using bcrypt
        val isValid = SecurityUtils.verifyPassword(password, user.passwordHash)

        return if (isValid) {
            // Reset failed attempts on successful login
            userDao.updateFailedAttempts(user.userId, 0)
            AuthResult.Success(user.userId, user.username)
        } else {
            // Increment failed attempts
            val newAttempts = user.failedLoginAttempts + 1
            userDao.updateFailedAttempts(user.userId, newAttempts)

            // Lock account if too many failures
            if (newAttempts >= User.MAX_FAILED_ATTEMPTS) {
                userDao.setAccountLocked(user.userId, true)
                AuthResult.AccountLocked
            } else {
                val remaining = User.MAX_FAILED_ATTEMPTS - newAttempts
                AuthResult.Error("Invalid password. $remaining attempts left.")
            }
        }
    }

    // ==================== WEIGHT OPERATIONS ====================

    suspend fun addWeightEntry(userId: Int, weight: Double, notes: String? = null): Long {
        val entry = WeightEntry(
            userId = userId,
            weight = weight,
            notes = notes?.let { SecurityUtils.sanitizeInput(it) }
        )
        return weightEntryDao.insertWeightEntry(entry)
    }

    suspend fun deleteWeightEntry(entry: WeightEntry) {
        weightEntryDao.deleteWeightEntry(entry)
    }

    fun observeWeightEntries(userId: Int): Flow<List<WeightEntry>> {
        return weightEntryDao.getAllWeightEntriesByUser(userId)
    }

    fun observeLatestWeight(userId: Int): Flow<WeightEntry?> {
        return weightEntryDao.observeLatestWeightEntry(userId)
    }

    suspend fun getLatestWeight(userId: Int): WeightEntry? {
        return weightEntryDao.getLatestWeightEntry(userId)
    }

    // ==================== GOAL OPERATIONS ====================

    suspend fun setGoalWeight(userId: Int, goalWeight: Double, startingWeight: Double): Long {
        val goal = GoalWeight(
            userId = userId,
            goalWeight = goalWeight,
            startingWeight = startingWeight
        )
        return goalWeightDao.insertGoalWeight(goal)
    }

    suspend fun getGoalWeight(userId: Int): GoalWeight? {
        return goalWeightDao.getGoalWeightByUser(userId)
    }

    fun observeGoalWeight(userId: Int): Flow<GoalWeight?> {
        return goalWeightDao.observeGoalWeight(userId)
    }

    suspend fun markGoalAchieved(userId: Int) {
        goalWeightDao.markGoalAchieved(userId, System.currentTimeMillis())
    }

    // ==================== EXPORT/IMPORT OPERATIONS ====================

    /**
     * Gets all weight entries for export.
     * Returns entries sorted by timestamp (oldest first).
     */
    suspend fun getAllEntriesForExport(userId: Int): List<WeightEntry> {
        return weightEntryDao.getAllEntriesOnce(userId)
    }

    /**
     * Imports multiple weight entries at once.
     * Uses bulk insert for efficiency.
     *
     * @param entries List of weight entries to import
     * @return Number of entries successfully imported
     */
    suspend fun importWeightEntries(entries: List<WeightEntry>): Int {
        if (entries.isEmpty()) return 0

        val results = weightEntryDao.insertAllWeightEntries(entries)
        return results.size
    }

    /**
     * Imports a single weight entry with duplicate checking.
     *
     * @param entry The entry to import
     * @param skipDuplicates If true, skips entries that already exist for the same day
     * @return True if imported, false if skipped
     */
    suspend fun importSingleEntry(entry: WeightEntry, skipDuplicates: Boolean = true): Boolean {
        if (skipDuplicates) {
            // Check for existing entry on the same day
            val dayStart = getDayStart(entry.timestamp)
            val dayEnd = dayStart + (24 * 60 * 60 * 1000) // 24 hours later

            val existingEntry = weightEntryDao.getEntryForDay(entry.userId, dayStart, dayEnd)
            if (existingEntry != null) {
                return false // Skip duplicate
            }
        }

        weightEntryDao.insertWeightEntry(entry)
        return true
    }

    /**
     * Deletes all entries for a user.
     * Used before restoring from backup.
     */
    suspend fun deleteAllEntries(userId: Int) {
        weightEntryDao.deleteAllEntriesForUser(userId)
    }

    // ==================== DATE RANGE QUERIES ====================

    /**
     * Gets entries within a date range.
     */
    suspend fun getEntriesInDateRange(userId: Int, startTime: Long, endTime: Long): List<WeightEntry> {
        return weightEntryDao.getEntriesInDateRange(userId, startTime, endTime)
    }

    /**
     * Gets entries from the last N days.
     */
    suspend fun getEntriesFromLastDays(userId: Int, days: Int): List<WeightEntry> {
        val sinceTimestamp = System.currentTimeMillis() - (days.toLong() * 24 * 60 * 60 * 1000)
        return weightEntryDao.getEntriesSince(userId, sinceTimestamp)
    }

    /**
     * Gets the most recent N entries.
     */
    suspend fun getRecentEntries(userId: Int, limit: Int): List<WeightEntry> {
        return weightEntryDao.getRecentEntries(userId, limit)
    }

    // ==================== STATISTICS QUERIES ====================

    /**
     * Gets statistics for a date range.
     */
    suspend fun getStatisticsForRange(
        userId: Int,
        startTime: Long,
        endTime: Long
    ): RangeStatistics {
        return RangeStatistics(
            average = weightEntryDao.getAverageWeightInRange(userId, startTime, endTime),
            min = weightEntryDao.getMinWeightInRange(userId, startTime, endTime),
            max = weightEntryDao.getMaxWeightInRange(userId, startTime, endTime),
            count = weightEntryDao.getEntryCountInRange(userId, startTime, endTime)
        )
    }

    /**
     * Gets total weight change from first to latest entry.
     */
    suspend fun getTotalWeightChange(userId: Int): Double? {
        return weightEntryDao.getTotalWeightChange(userId)
    }

    /**
     * Gets the first entry ever recorded.
     */
    suspend fun getFirstEntry(userId: Int): WeightEntry? {
        return weightEntryDao.getFirstEntry(userId)
    }

    // ==================== HELPER FUNCTIONS ====================

    /**
     * Gets the start of the day (midnight) for a given timestamp.
     */
    private fun getDayStart(timestamp: Long): Long {
        val millisInDay = 24 * 60 * 60 * 1000L
        return (timestamp / millisInDay) * millisInDay
    }

    // ==================== DATA CLASSES ====================

    /**
     * Statistics for a date range.
     */
    data class RangeStatistics(
        val average: Double?,
        val min: Double?,
        val max: Double?,
        val count: Int
    )
}