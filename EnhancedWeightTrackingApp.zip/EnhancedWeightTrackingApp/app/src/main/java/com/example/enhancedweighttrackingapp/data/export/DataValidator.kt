package com.example.weight_trackingapp.data.export

/**
 * DataValidator - Validates and sanitizes data for database operations.
 *
 * FEATURES:
 * - Weight validation (range checking)
 * - Username/password validation
 * - SQL injection prevention
 * - Input sanitization
 *
 * COURSE OUTCOME 5: Develop a security mindset in database operations
 */
object DataValidator {

    // Weight constraints
    const val MIN_WEIGHT = 50.0    // Minimum reasonable weight (lbs)
    const val MAX_WEIGHT = 1000.0  // Maximum reasonable weight (lbs)

    // Username constraints
    const val MIN_USERNAME_LENGTH = 3
    const val MAX_USERNAME_LENGTH = 50

    // Password constraints
    const val MIN_PASSWORD_LENGTH = 4
    const val MAX_PASSWORD_LENGTH = 100

    /**
     * Validates a weight value.
     *
     * @param weight The weight to validate
     * @return ValidationResult indicating success or specific error
     */
    fun validateWeight(weight: Double?): ValidationResult {
        return when {
            weight == null -> ValidationResult.Error("Weight is required")
            weight <= 0 -> ValidationResult.Error("Weight must be positive")
            weight < MIN_WEIGHT -> ValidationResult.Error("Weight must be at least $MIN_WEIGHT lbs")
            weight > MAX_WEIGHT -> ValidationResult.Error("Weight must be less than $MAX_WEIGHT lbs")
            weight.isNaN() -> ValidationResult.Error("Invalid weight value")
            weight.isInfinite() -> ValidationResult.Error("Invalid weight value")
            else -> ValidationResult.Success
        }
    }

    /**
     * Validates a weight string and parses it.
     *
     * @param weightStr The weight string to validate
     * @return Pair of ValidationResult and parsed weight (null if invalid)
     */
    fun validateAndParseWeight(weightStr: String?): Pair<ValidationResult, Double?> {
        if (weightStr.isNullOrBlank()) {
            return Pair(ValidationResult.Error("Weight is required"), null)
        }

        val weight = weightStr.trim().toDoubleOrNull()
        if (weight == null) {
            return Pair(ValidationResult.Error("Invalid weight format"), null)
        }

        val result = validateWeight(weight)
        return Pair(result, if (result is ValidationResult.Success) weight else null)
    }

    /**
     * Validates a username.
     *
     * @param username The username to validate
     * @return ValidationResult indicating success or specific error
     */
    fun validateUsername(username: String?): ValidationResult {
        return when {
            username.isNullOrBlank() -> ValidationResult.Error("Username is required")
            username.length < MIN_USERNAME_LENGTH ->
                ValidationResult.Error("Username must be at least $MIN_USERNAME_LENGTH characters")
            username.length > MAX_USERNAME_LENGTH ->
                ValidationResult.Error("Username must be less than $MAX_USERNAME_LENGTH characters")
            !username.matches(Regex("^[a-zA-Z0-9_]+$")) ->
                ValidationResult.Error("Username can only contain letters, numbers, and underscores")
            else -> ValidationResult.Success
        }
    }

    /**
     * Validates a password.
     *
     * @param password The password to validate
     * @return ValidationResult indicating success or specific error
     */
    fun validatePassword(password: String?): ValidationResult {
        return when {
            password.isNullOrBlank() -> ValidationResult.Error("Password is required")
            password.length < MIN_PASSWORD_LENGTH ->
                ValidationResult.Error("Password must be at least $MIN_PASSWORD_LENGTH characters")
            password.length > MAX_PASSWORD_LENGTH ->
                ValidationResult.Error("Password must be less than $MAX_PASSWORD_LENGTH characters")
            else -> ValidationResult.Success
        }
    }

    /**
     * Validates a goal weight.
     *
     * @param goalWeight The goal weight to validate
     * @param currentWeight Optional current weight for comparison
     * @return ValidationResult indicating success or specific error
     */
    fun validateGoalWeight(goalWeight: Double?, currentWeight: Double? = null): ValidationResult {
        val baseValidation = validateWeight(goalWeight)
        if (baseValidation is ValidationResult.Error) {
            return baseValidation
        }

        // Additional goal-specific validation could go here
        // For example, warning if goal is very far from current weight

        return ValidationResult.Success
    }

    /**
     * Validates a timestamp.
     *
     * @param timestamp The timestamp to validate
     * @return ValidationResult indicating success or specific error
     */
    fun validateTimestamp(timestamp: Long?): ValidationResult {
        val now = System.currentTimeMillis()
        val oneYearAgo = now - (365L * 24 * 60 * 60 * 1000)
        val oneDayFuture = now + (24 * 60 * 60 * 1000)

        return when {
            timestamp == null -> ValidationResult.Error("Timestamp is required")
            timestamp < oneYearAgo -> ValidationResult.Error("Date is too far in the past")
            timestamp > oneDayFuture -> ValidationResult.Error("Date cannot be in the future")
            else -> ValidationResult.Success
        }
    }

    /**
     * Sanitizes a string for safe database storage.
     * Removes potentially harmful characters.
     *
     * @param input The string to sanitize
     * @return Sanitized string
     */
    fun sanitizeString(input: String?): String {
        if (input.isNullOrBlank()) return ""

        return input
            .trim()
            .replace(Regex("[<>\"'&]"), "") // Remove HTML/SQL special chars
            .take(500) // Limit length
    }

    /**
     * Validates an entire weight entry before database insertion.
     *
     * @param weight The weight value
     * @param timestamp The timestamp
     * @param userId The user ID
     * @return ValidationResult indicating success or first error found
     */
    fun validateWeightEntry(weight: Double?, timestamp: Long?, userId: Int?): ValidationResult {
        // Validate user ID
        if (userId == null || userId <= 0) {
            return ValidationResult.Error("Invalid user")
        }

        // Validate weight
        val weightResult = validateWeight(weight)
        if (weightResult is ValidationResult.Error) {
            return weightResult
        }

        // Validate timestamp
        val timestampResult = validateTimestamp(timestamp)
        if (timestampResult is ValidationResult.Error) {
            return timestampResult
        }

        return ValidationResult.Success
    }

    /**
     * Result class for validation operations.
     */
    sealed class ValidationResult {
        object Success : ValidationResult()
        data class Error(val message: String) : ValidationResult()

        fun isValid(): Boolean = this is Success

        fun getErrorMessage(): String? = (this as? Error)?.message
    }
}