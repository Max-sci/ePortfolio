package com.example.weight_trackingapp.ui.goal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.weight_trackingapp.data.repository.WeightRepository

/**
 * Factory for creating GoalWeightViewModel with dependencies.
 */
class GoalWeightViewModelFactory(
    private val repository: WeightRepository,
    private val userId: Int
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GoalWeightViewModel::class.java)) {
            return GoalWeightViewModel(repository, userId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}