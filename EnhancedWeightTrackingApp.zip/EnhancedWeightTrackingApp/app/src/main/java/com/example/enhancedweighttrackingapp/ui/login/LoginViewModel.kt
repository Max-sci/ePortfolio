package com.example.weight_trackingapp.ui.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weight_trackingapp.data.repository.WeightRepository
import kotlinx.coroutines.launch

/**
 * ViewModel for Login screen.
 *
 * MVVM ARCHITECTURE:
 * - Holds UI state (survives screen rotation)
 * - Processes user actions
 * - Exposes data via LiveData (reactive updates)
 */
class LoginViewModel(
    private val repository: WeightRepository
) : ViewModel() {

    // ==================== UI STATE ====================

    sealed class LoginState {
        object Idle : LoginState()
        object Loading : LoginState()
        data class Success(val userId: Int, val username: String) : LoginState()
        data class Error(val message: String) : LoginState()
        object AccountLocked : LoginState()
    }

    private val _loginState = MutableLiveData<LoginState>(LoginState.Idle)
    val loginState: LiveData<LoginState> = _loginState

    private val _usernameError = MutableLiveData<String?>()
    val usernameError: LiveData<String?> = _usernameError

    private val _passwordError = MutableLiveData<String?>()
    val passwordError: LiveData<String?> = _passwordError

    // ==================== USER ACTIONS ====================

    /**
     * Attempts to log in.
     */
    fun login(username: String, password: String) {
        // Clear previous errors
        _usernameError.value = null
        _passwordError.value = null

        // Validate inputs
        if (username.isBlank()) {
            _usernameError.value = "Username is required"
            return
        }
        if (password.isBlank()) {
            _passwordError.value = "Password is required"
            return
        }

        _loginState.value = LoginState.Loading

        viewModelScope.launch {
            when (val result = repository.loginUser(username, password)) {
                is WeightRepository.AuthResult.Success -> {
                    _loginState.value = LoginState.Success(result.userId, result.username)
                }
                is WeightRepository.AuthResult.Error -> {
                    _loginState.value = LoginState.Error(result.message)
                }
                is WeightRepository.AuthResult.AccountLocked -> {
                    _loginState.value = LoginState.AccountLocked
                }
            }
        }
    }

    /**
     * Attempts to register a new user.
     */
    fun register(username: String, password: String, confirmPassword: String) {
        // Clear previous errors
        _usernameError.value = null
        _passwordError.value = null

        // Validate inputs
        if (username.isBlank()) {
            _usernameError.value = "Username is required"
            return
        }
        if (password.isBlank()) {
            _passwordError.value = "Password is required"
            return
        }
        if (password != confirmPassword) {
            _passwordError.value = "Passwords do not match"
            return
        }

        _loginState.value = LoginState.Loading

        viewModelScope.launch {
            when (val result = repository.registerUser(username, password)) {
                is WeightRepository.AuthResult.Success -> {
                    _loginState.value = LoginState.Success(result.userId, result.username)
                }
                is WeightRepository.AuthResult.Error -> {
                    _loginState.value = LoginState.Error(result.message)
                }
                is WeightRepository.AuthResult.AccountLocked -> {
                    _loginState.value = LoginState.Error("Unexpected error")
                }
            }
        }
    }

    /**
     * Resets state to idle.
     */
    fun resetState() {
        _loginState.value = LoginState.Idle
    }
}