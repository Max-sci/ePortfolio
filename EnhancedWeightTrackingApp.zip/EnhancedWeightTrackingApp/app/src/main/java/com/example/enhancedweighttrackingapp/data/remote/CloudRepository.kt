package com.example.weight_trackingapp.data.remote

/**
 * Cloud Repository - Handles all cloud database operations
 *
 * Communicates with MongoDB Atlas via the Node.js backend
 * Implements JWT authentication for secure API access
 *
 * COURSE OUTCOME: Cloud database integration with RESTful API
 */
class CloudRepository {

    private val api = RetrofitClient.apiService

    // ==================== AUTH OPERATIONS ====================

    /**
     * Register a new user in the cloud database
     */
    suspend fun register(username: String, password: String): CloudResult<AuthResponse> {
        return try {
            val response = api.register(RegisterRequest(username, password))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Registration failed: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Login user and get JWT token
     */
    suspend fun login(username: String, password: String): CloudResult<AuthResponse> {
        return try {
            val response = api.login(LoginRequest(username, password))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Login failed: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    // ==================== WEIGHT OPERATIONS ====================

    /**
     * Get all weight entries from cloud
     */
    suspend fun getWeightEntries(token: String): CloudResult<List<WeightEntryResponse>> {
        return try {
            val response = api.getWeightEntries(RetrofitClient.bearerToken(token))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to get entries: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Create a new weight entry in cloud
     */
    suspend fun createWeightEntry(token: String, weight: Double, timestamp: Long?): CloudResult<WeightEntryResponse> {
        return try {
            val request = WeightEntryRequest(weight, timestamp, null)
            val response = api.createWeightEntry(RetrofitClient.bearerToken(token), request)
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to create entry: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Delete a weight entry from cloud
     */
    suspend fun deleteWeightEntry(token: String, entryId: String): CloudResult<DeleteResponse> {
        return try {
            val response = api.deleteWeightEntry(RetrofitClient.bearerToken(token), entryId)
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to delete entry: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Sync multiple entries to cloud
     */
    suspend fun syncEntries(token: String, entries: List<WeightEntryRequest>): CloudResult<SyncResponse> {
        return try {
            val response = api.syncWeightEntries(RetrofitClient.bearerToken(token), SyncRequest(entries))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Sync failed: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    // ==================== GOAL OPERATIONS ====================

    /**
     * Get goal weight from cloud
     */
    suspend fun getGoal(token: String): CloudResult<GoalResponse> {
        return try {
            val response = api.getGoal(RetrofitClient.bearerToken(token))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("No goal set")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Set goal weight in cloud
     */
    suspend fun setGoal(token: String, goalWeight: Double, startingWeight: Double): CloudResult<GoalResponse> {
        return try {
            val request = GoalRequest(goalWeight, startingWeight)
            val response = api.setGoal(RetrofitClient.bearerToken(token), request)
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to set goal: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    // ==================== STATS OPERATIONS ====================

    /**
     * Get statistics summary from cloud (aggregation pipeline)
     */
    suspend fun getStatsSummary(token: String): CloudResult<StatsSummaryResponse> {
        return try {
            val response = api.getStatsSummary(RetrofitClient.bearerToken(token))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to get stats: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Get weekly statistics (aggregation pipeline)
     */
    suspend fun getWeeklyStats(token: String): CloudResult<List<WeeklyStatsResponse>> {
        return try {
            val response = api.getWeeklyStats(RetrofitClient.bearerToken(token))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to get weekly stats: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Get monthly statistics (aggregation pipeline)
     */
    suspend fun getMonthlyStats(token: String): CloudResult<List<MonthlyStatsResponse>> {
        return try {
            val response = api.getMonthlyStats(RetrofitClient.bearerToken(token))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to get monthly stats: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Get trend analysis (aggregation pipeline)
     */
    suspend fun getTrend(token: String): CloudResult<TrendResponse> {
        return try {
            val response = api.getTrend(RetrofitClient.bearerToken(token))
            if (response.isSuccessful && response.body() != null) {
                CloudResult.Success(response.body()!!)
            } else {
                CloudResult.Error("Failed to get trend: ${response.message()}")
            }
        } catch (e: Exception) {
            CloudResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Result wrapper for cloud operations
     */
    sealed class CloudResult<out T> {
        data class Success<T>(val data: T) : CloudResult<T>()
        data class Error(val message: String) : CloudResult<Nothing>()
    }
}