package com.example.weight_trackingapp.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Secure Session Manager using encrypted storage.
 *
 * SECURITY IMPROVEMENTS:
 * - AES256 encryption for stored data
 * - Session timeout after 7 days
 * - JWT token storage for cloud API authentication
 *
 * COURSE OUTCOME: JWT Token Authentication
 */
class SecureSessionManager(context: Context) {

    companion object {
        private const val PREF_NAME = "secure_session"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USERNAME = "username"
        private const val KEY_LOGIN_TIME = "login_time"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_JWT_TOKEN = "jwt_token"
        private const val KEY_CLOUD_USER_ID = "cloud_user_id"
        private const val KEY_IS_CLOUD_SYNCED = "is_cloud_synced"

        // Session expires after 7 days
        private const val SESSION_TIMEOUT_MS = 7 * 24 * 60 * 60 * 1000L
    }

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val preferences: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        PREF_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    /**
     * Creates a new login session (local only).
     */
    fun createLoginSession(userId: Int, username: String) {
        preferences.edit().apply {
            putInt(KEY_USER_ID, userId)
            putString(KEY_USERNAME, username)
            putLong(KEY_LOGIN_TIME, System.currentTimeMillis())
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }

    /**
     * Creates a login session with cloud authentication.
     * Stores JWT token for API calls.
     */
    fun createCloudLoginSession(userId: Int, username: String, jwtToken: String, cloudUserId: String) {
        preferences.edit().apply {
            putInt(KEY_USER_ID, userId)
            putString(KEY_USERNAME, username)
            putLong(KEY_LOGIN_TIME, System.currentTimeMillis())
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_JWT_TOKEN, jwtToken)
            putString(KEY_CLOUD_USER_ID, cloudUserId)
            putBoolean(KEY_IS_CLOUD_SYNCED, true)
            apply()
        }
    }

    /**
     * Saves JWT token after cloud registration/login.
     */
    fun saveCloudCredentials(jwtToken: String, cloudUserId: String) {
        preferences.edit().apply {
            putString(KEY_JWT_TOKEN, jwtToken)
            putString(KEY_CLOUD_USER_ID, cloudUserId)
            putBoolean(KEY_IS_CLOUD_SYNCED, true)
            apply()
        }
    }

    /**
     * Gets the JWT token for API authentication.
     */
    fun getJwtToken(): String? {
        return preferences.getString(KEY_JWT_TOKEN, null)
    }

    /**
     * Gets the cloud user ID.
     */
    fun getCloudUserId(): String? {
        return preferences.getString(KEY_CLOUD_USER_ID, null)
    }

    /**
     * Checks if user has cloud sync enabled.
     */
    fun isCloudSynced(): Boolean {
        return preferences.getBoolean(KEY_IS_CLOUD_SYNCED, false)
    }

    /**
     * Checks if user is logged in and session is valid.
     */
    fun isLoggedIn(): Boolean {
        val isLoggedIn = preferences.getBoolean(KEY_IS_LOGGED_IN, false)
        if (!isLoggedIn) return false

        // Check if session has expired
        val loginTime = preferences.getLong(KEY_LOGIN_TIME, 0)
        if (System.currentTimeMillis() - loginTime > SESSION_TIMEOUT_MS) {
            logout()
            return false
        }

        return true
    }

    /**
     * Gets the logged in user's ID.
     */
    fun getUserId(): Int {
        return if (isLoggedIn()) {
            preferences.getInt(KEY_USER_ID, -1)
        } else {
            -1
        }
    }

    /**
     * Gets the logged in user's username.
     */
    fun getUsername(): String? {
        return if (isLoggedIn()) {
            preferences.getString(KEY_USERNAME, null)
        } else {
            null
        }
    }

    /**
     * Refreshes the session timeout.
     */
    fun refreshSession() {
        if (isLoggedIn()) {
            preferences.edit()
                .putLong(KEY_LOGIN_TIME, System.currentTimeMillis())
                .apply()
        }
    }

    /**
     * Logs out the user and clears session data.
     */
    fun logout() {
        preferences.edit().clear().apply()
    }

    /**
     * Clears only cloud credentials (keeps local session).
     */
    fun clearCloudCredentials() {
        preferences.edit().apply {
            remove(KEY_JWT_TOKEN)
            remove(KEY_CLOUD_USER_ID)
            putBoolean(KEY_IS_CLOUD_SYNCED, false)
            apply()
        }
    }
}