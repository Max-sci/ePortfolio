package com.example.weight_trackingapp.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * WeightEntry Entity - Represents a single weight measurement.
 *
 * DESIGN IMPROVEMENTS:
 * - Uses Long timestamp instead of String for proper date sorting
 * - Foreign key ensures data integrity (deletes entries if user deleted)
 * - Indexed for fast lookups
 */
@Entity(
    tableName = "weight_entries",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"])]
)
data class WeightEntry(
    @PrimaryKey(autoGenerate = true)
    val entryId: Int = 0,

    val userId: Int,

    val weight: Double,

    val timestamp: Long = System.currentTimeMillis(),

    val notes: String? = null
)