package com.example.weight_trackingapp.data.export

import android.content.Context
import android.net.Uri
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * DataImporter - Handles importing weight data from various formats.
 *
 * SUPPORTED FORMATS:
 * - CSV: Imports date and weight columns
 * - JSON: Full restore including goal weight
 *
 * FEATURES:
 * - Data validation
 * - Duplicate detection
 * - Error reporting
 *
 * COURSE OUTCOME 4: Implementing database solutions that deliver value
 */
class DataImporter(private val context: Context) {

    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    /**
     * Imports weight entries from a CSV file.
     *
     * Expected CSV format:
     * Date,Weight (lbs),Timestamp
     * 2024-01-15,185.5,1705312800000
     *
     * @param uri Source URI of the CSV file
     * @param userId User ID to assign to imported entries
     * @return ImportResult with parsed entries or error
     */
    fun importFromCsv(uri: Uri, userId: Int): ImportResult {
        val entries = mutableListOf<WeightEntry>()
        val errors = mutableListOf<String>()
        var lineNumber = 0

        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    var line: String?
                    var isHeader = true

                    while (reader.readLine().also { line = it } != null) {
                        lineNumber++

                        // Skip header row
                        if (isHeader) {
                            isHeader = false
                            continue
                        }

                        // Skip empty lines
                        if (line.isNullOrBlank()) continue

                        // Parse CSV line
                        val result = parseCsvLine(line!!, lineNumber, userId)
                        when (result) {
                            is ParseResult.Success -> entries.add(result.entry)
                            is ParseResult.Error -> errors.add(result.message)
                        }
                    }
                }
            }

            if (entries.isEmpty() && errors.isNotEmpty()) {
                ImportResult.Error("No valid entries found. Errors: ${errors.joinToString("; ")}")
            } else {
                ImportResult.Success(
                    entries = entries,
                    goalWeight = null,
                    importedCount = entries.size,
                    skippedCount = errors.size,
                    warnings = errors
                )
            }
        } catch (e: Exception) {
            ImportResult.Error("Failed to import CSV: ${e.message}")
        }
    }

    /**
     * Parses a single CSV line into a WeightEntry.
     */
    private fun parseCsvLine(line: String, lineNumber: Int, userId: Int): ParseResult {
        val parts = line.split(",").map { it.trim() }

        if (parts.size < 2) {
            return ParseResult.Error("Line $lineNumber: Invalid format (expected at least 2 columns)")
        }

        val dateStr = parts[0]
        val weightStr = parts[1]

        // Parse weight
        val weight = weightStr.toDoubleOrNull()
        if (weight == null || weight <= 0 || weight > 1000) {
            return ParseResult.Error("Line $lineNumber: Invalid weight value '$weightStr'")
        }

        // Parse timestamp (either from column 3 or from date)
        val timestamp = if (parts.size >= 3) {
            parts[2].toLongOrNull() ?: parseDate(dateStr)
        } else {
            parseDate(dateStr)
        }

        if (timestamp == null) {
            return ParseResult.Error("Line $lineNumber: Invalid date '$dateStr'")
        }

        return ParseResult.Success(
            WeightEntry(
                entryId = 0, // Auto-generate
                userId = userId,
                weight = weight,
                timestamp = timestamp
            )
        )
    }

    /**
     * Parses a date string to timestamp.
     */
    private fun parseDate(dateStr: String): Long? {
        return try {
            dateFormatter.parse(dateStr)?.time
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Imports data from a JSON backup file.
     *
     * @param uri Source URI of the JSON file
     * @param userId User ID to assign to imported entries
     * @return ImportResult with parsed data or error
     */
    fun importFromJson(uri: Uri, userId: Int): ImportResult {
        return try {
            val jsonString = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).readText()
            } ?: return ImportResult.Error("Could not read file")

            val jsonObject = JSONObject(jsonString)
            val entries = mutableListOf<WeightEntry>()
            val warnings = mutableListOf<String>()

            // Parse weight entries
            val entriesArray = jsonObject.optJSONArray("weightEntries")
            if (entriesArray != null) {
                for (i in 0 until entriesArray.length()) {
                    val entryJson = entriesArray.getJSONObject(i)

                    val weight = entryJson.optDouble("weight", -1.0)
                    val timestamp = entryJson.optLong("timestamp", -1L)

                    if (weight > 0 && timestamp > 0) {
                        entries.add(
                            WeightEntry(
                                entryId = 0,
                                userId = userId,
                                weight = weight,
                                timestamp = timestamp
                            )
                        )
                    } else {
                        warnings.add("Skipped invalid entry at index $i")
                    }
                }
            }

            // Parse goal weight
            var goalWeight: GoalWeight? = null
            val goalJson = jsonObject.optJSONObject("goalWeight")
            if (goalJson != null) {
                val weight = goalJson.optDouble("weight", -1.0)
                val startingWeight = goalJson.optDouble("startingWeight", -1.0)
                val setDate = goalJson.optLong("setDate", System.currentTimeMillis())

                if (weight > 0 && startingWeight > 0) {
                    goalWeight = GoalWeight(
                        goalId = 0,
                        userId = userId,
                        goalWeight = weight,
                        startingWeight = startingWeight,
                        createdAt = setDate
                    )
                }
            }

            ImportResult.Success(
                entries = entries,
                goalWeight = goalWeight,
                importedCount = entries.size,
                skippedCount = warnings.size,
                warnings = warnings
            )
        } catch (e: Exception) {
            ImportResult.Error("Failed to import JSON: ${e.message}")
        }
    }

    /**
     * Detects the format of a file based on content.
     */
    fun detectFormat(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val firstChar = inputStream.read().toChar()
                when (firstChar) {
                    '{' -> "json"
                    else -> "csv"
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Result classes for parsing operations.
     */
    private sealed class ParseResult {
        data class Success(val entry: WeightEntry) : ParseResult()
        data class Error(val message: String) : ParseResult()
    }

    /**
     * Result class for import operations.
     */
    sealed class ImportResult {
        data class Success(
            val entries: List<WeightEntry>,
            val goalWeight: GoalWeight?,
            val importedCount: Int,
            val skippedCount: Int,
            val warnings: List<String>
        ) : ImportResult()

        data class Error(val message: String) : ImportResult()
    }
}