package com.example.weight_trackingapp.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for WeightEntry operations.
 *
 * DESIGN IMPROVEMENTS:
 * - Flow for reactive UI updates
 * - Suspend functions for async operations
 * - Advanced queries for date ranges and statistics
 * - Bulk operations for import/export
 *
 * COURSE OUTCOME 4: Use well-founded techniques for database operations
 */
@Dao
interface WeightEntryDao {

    // ==================== BASIC CRUD OPERATIONS ====================

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightEntry(weightEntry: WeightEntry): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllWeightEntries(entries: List<WeightEntry>): List<Long>

    @Update
    suspend fun updateWeightEntry(weightEntry: WeightEntry)

    @Delete
    suspend fun deleteWeightEntry(weightEntry: WeightEntry)

    @Query("DELETE FROM weight_entries WHERE entryId = :entryId")
    suspend fun deleteWeightEntryById(entryId: Int)

    @Query("DELETE FROM weight_entries WHERE userId = :userId")
    suspend fun deleteAllEntriesForUser(userId: Int)

    // ==================== QUERY OPERATIONS ====================

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC")
    fun getAllWeightEntriesByUser(userId: Int): Flow<List<WeightEntry>>

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp ASC")
    suspend fun getAllEntriesOnce(userId: Int): List<WeightEntry>

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestWeightEntry(userId: Int): WeightEntry?

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC LIMIT 1")
    fun observeLatestWeightEntry(userId: Int): Flow<WeightEntry?>

    @Query("SELECT * FROM weight_entries WHERE entryId = :entryId")
    suspend fun getEntryById(entryId: Int): WeightEntry?

    // ==================== DATE RANGE QUERIES ====================

    /**
     * Get entries within a specific date range.
     * Useful for weekly/monthly reports.
     */
    @Query("""
        SELECT * FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :startTime 
        AND timestamp <= :endTime 
        ORDER BY timestamp ASC
    """)
    suspend fun getEntriesInDateRange(userId: Int, startTime: Long, endTime: Long): List<WeightEntry>

    /**
     * Get entries from the last N days.
     */
    @Query("""
        SELECT * FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :sinceTimestamp 
        ORDER BY timestamp ASC
    """)
    suspend fun getEntriesSince(userId: Int, sinceTimestamp: Long): List<WeightEntry>

    /**
     * Get the most recent N entries.
     */
    @Query("""
        SELECT * FROM weight_entries 
        WHERE userId = :userId 
        ORDER BY timestamp DESC 
        LIMIT :limit
    """)
    suspend fun getRecentEntries(userId: Int, limit: Int): List<WeightEntry>

    // ==================== STATISTICS QUERIES ====================

    @Query("SELECT COUNT(*) FROM weight_entries WHERE userId = :userId")
    suspend fun getEntryCount(userId: Int): Int

    @Query("SELECT MIN(weight) FROM weight_entries WHERE userId = :userId")
    suspend fun getMinWeight(userId: Int): Double?

    @Query("SELECT MAX(weight) FROM weight_entries WHERE userId = :userId")
    suspend fun getMaxWeight(userId: Int): Double?

    @Query("SELECT AVG(weight) FROM weight_entries WHERE userId = :userId")
    suspend fun getAverageWeight(userId: Int): Double?

    /**
     * Get statistics for a date range.
     */
    @Query("""
        SELECT AVG(weight) FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :startTime 
        AND timestamp <= :endTime
    """)
    suspend fun getAverageWeightInRange(userId: Int, startTime: Long, endTime: Long): Double?

    @Query("""
        SELECT MIN(weight) FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :startTime 
        AND timestamp <= :endTime
    """)
    suspend fun getMinWeightInRange(userId: Int, startTime: Long, endTime: Long): Double?

    @Query("""
        SELECT MAX(weight) FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :startTime 
        AND timestamp <= :endTime
    """)
    suspend fun getMaxWeightInRange(userId: Int, startTime: Long, endTime: Long): Double?

    @Query("""
        SELECT COUNT(*) FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :startTime 
        AND timestamp <= :endTime
    """)
    suspend fun getEntryCountInRange(userId: Int, startTime: Long, endTime: Long): Int

    // ==================== DUPLICATE DETECTION ====================

    /**
     * Check if an entry exists for a specific date (same day).
     * Used to prevent duplicate entries on import.
     */
    @Query("""
        SELECT * FROM weight_entries 
        WHERE userId = :userId 
        AND timestamp >= :dayStart 
        AND timestamp < :dayEnd 
        LIMIT 1
    """)
    suspend fun getEntryForDay(userId: Int, dayStart: Long, dayEnd: Long): WeightEntry?

    /**
     * Get the first entry ever recorded.
     */
    @Query("""
        SELECT * FROM weight_entries 
        WHERE userId = :userId 
        ORDER BY timestamp ASC 
        LIMIT 1
    """)
    suspend fun getFirstEntry(userId: Int): WeightEntry?

    /**
     * Calculate total weight change (latest - first).
     */
    @Query("""
        SELECT 
            (SELECT weight FROM weight_entries WHERE userId = :userId ORDER BY timestamp DESC LIMIT 1) -
            (SELECT weight FROM weight_entries WHERE userId = :userId ORDER BY timestamp ASC LIMIT 1)
        AS weightChange
    """)
    suspend fun getTotalWeightChange(userId: Int): Double?
}