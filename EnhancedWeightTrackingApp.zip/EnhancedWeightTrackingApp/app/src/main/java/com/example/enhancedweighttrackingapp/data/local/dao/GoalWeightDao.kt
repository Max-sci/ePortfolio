package com.example.weight_trackingapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for GoalWeight operations.
 *
 * DESIGN IMPROVEMENTS:
 * - One goal per user (enforced by unique index)
 * - Reactive observation of goal changes
 * - Goal achievement tracking
 */
@Dao
interface GoalWeightDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoalWeight(goalWeight: GoalWeight): Long

    @Update
    suspend fun updateGoalWeight(goalWeight: GoalWeight)

    @Query("SELECT * FROM goal_weights WHERE userId = :userId LIMIT 1")
    suspend fun getGoalWeightByUser(userId: Int): GoalWeight?

    @Query("SELECT * FROM goal_weights WHERE userId = :userId LIMIT 1")
    fun observeGoalWeight(userId: Int): Flow<GoalWeight?>

    @Query("UPDATE goal_weights SET isAchieved = 1, achievedAt = :achievedAt WHERE userId = :userId")
    suspend fun markGoalAchieved(userId: Int, achievedAt: Long)

    @Query("DELETE FROM goal_weights WHERE userId = :userId")
    suspend fun deleteGoal(userId: Int)
}