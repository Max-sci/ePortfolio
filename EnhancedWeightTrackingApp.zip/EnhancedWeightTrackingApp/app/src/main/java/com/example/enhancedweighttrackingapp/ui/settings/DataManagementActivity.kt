package com.example.weight_trackingapp.ui.settings

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.export.DataExporter
import com.example.weight_trackingapp.data.export.DataImporter
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

/**
 * DataManagementActivity - Handles data export and import operations.
 *
 * FEATURES:
 * - Export to CSV (spreadsheet compatible)
 * - Export to JSON (full backup)
 * - Import from CSV
 * - Import from JSON (restore backup)
 *
 * COURSE OUTCOME 4: Implementing database solutions that deliver value
 */
class DataManagementActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager
    private lateinit var repository: WeightRepository
    private lateinit var dataExporter: DataExporter
    private lateinit var dataImporter: DataImporter

    // Views
    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnExportCsv: MaterialButton
    private lateinit var btnExportJson: MaterialButton
    private lateinit var btnImportCsv: MaterialButton
    private lateinit var btnImportJson: MaterialButton

    // Activity result launchers for file picking
    private val exportCsvLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        uri?.let { exportToCsv(it) }
    }

    private val exportJsonLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let { exportToJson(it) }
    }

    private val importFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { importFromFile(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_management)

        sessionManager = SecureSessionManager(this)

        val database = AppDatabase.getInstance(applicationContext)
        repository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )

        dataExporter = DataExporter(this)
        dataImporter = DataImporter(this)

        initializeViews()
        setupToolbar()
        setupClickListeners()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        btnExportCsv = findViewById(R.id.btnExportCsv)
        btnExportJson = findViewById(R.id.btnExportJson)
        btnImportCsv = findViewById(R.id.btnImportCsv)
        btnImportJson = findViewById(R.id.btnImportJson)
    }

    private fun setupToolbar() {
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupClickListeners() {
        btnExportCsv.setOnClickListener {
            val filename = dataExporter.generateFilename("csv")
            exportCsvLauncher.launch(filename)
        }

        btnExportJson.setOnClickListener {
            val filename = dataExporter.generateFilename("json")
            exportJsonLauncher.launch(filename)
        }

        btnImportCsv.setOnClickListener {
            showImportWarningDialog("CSV") {
                importFileLauncher.launch(arrayOf("text/csv", "text/comma-separated-values", "*/*"))
            }
        }

        btnImportJson.setOnClickListener {
            showImportWarningDialog("JSON") {
                importFileLauncher.launch(arrayOf("application/json", "*/*"))
            }
        }
    }

    private fun exportToCsv(uri: Uri) {
        lifecycleScope.launch {
            try {
                val userId = sessionManager.getUserId()
                val entries = repository.getAllEntriesForExport(userId)

                if (entries.isEmpty()) {
                    showToast("No entries to export")
                    return@launch
                }

                val result = dataExporter.exportToCsv(entries, uri)

                when (result) {
                    is DataExporter.ExportResult.Success -> {
                        showToast("Exported ${result.count} entries to CSV")
                    }
                    is DataExporter.ExportResult.Error -> {
                        showToast("Export failed: ${result.message}")
                    }
                }
            } catch (e: Exception) {
                showToast("Export failed: ${e.message}")
            }
        }
    }

    private fun exportToJson(uri: Uri) {
        lifecycleScope.launch {
            try {
                val userId = sessionManager.getUserId()
                val entries = repository.getAllEntriesForExport(userId)
                val goalWeight = repository.getGoalWeight(userId)

                if (entries.isEmpty()) {
                    showToast("No entries to export")
                    return@launch
                }

                val result = dataExporter.exportToJson(entries, goalWeight, uri)

                when (result) {
                    is DataExporter.ExportResult.Success -> {
                        showToast("Backup complete: ${result.count} entries")
                    }
                    is DataExporter.ExportResult.Error -> {
                        showToast("Backup failed: ${result.message}")
                    }
                }
            } catch (e: Exception) {
                showToast("Backup failed: ${e.message}")
            }
        }
    }

    private fun importFromFile(uri: Uri) {
        lifecycleScope.launch {
            try {
                val userId = sessionManager.getUserId()
                val format = dataImporter.detectFormat(uri)

                val result = when (format) {
                    "json" -> dataImporter.importFromJson(uri, userId)
                    else -> dataImporter.importFromCsv(uri, userId)
                }

                when (result) {
                    is DataImporter.ImportResult.Success -> {
                        // Import the entries
                        var importedCount = 0
                        for (entry in result.entries) {
                            val imported = repository.importSingleEntry(entry, skipDuplicates = true)
                            if (imported) importedCount++
                        }

                        // Import goal weight if present
                        result.goalWeight?.let { goal ->
                            repository.setGoalWeight(userId, goal.goalWeight, goal.startingWeight)
                        }

                        val message = buildString {
                            append("Imported $importedCount entries")
                            if (result.skippedCount > 0) {
                                append(", skipped ${result.skippedCount}")
                            }
                            if (result.goalWeight != null) {
                                append(", goal weight restored")
                            }
                        }
                        showToast(message)
                    }
                    is DataImporter.ImportResult.Error -> {
                        showToast("Import failed: ${result.message}")
                    }
                }
            } catch (e: Exception) {
                showToast("Import failed: ${e.message}")
            }
        }
    }

    private fun showImportWarningDialog(format: String, onConfirm: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("Import $format Data")
            .setMessage("This will add entries from the file to your existing data. Duplicate dates will be skipped.\n\nContinue?")
            .setPositiveButton("Import") { _, _ -> onConfirm() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}