package com.example.weight_trackingapp.ui.history

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RecyclerView Adapter for displaying weight entries.
 *
 * DESIGN IMPROVEMENTS:
 * - Uses ListAdapter with DiffUtil for efficient updates
 * - Click listener for delete action
 */
class WeightEntryAdapter(
    private val onDeleteClick: (WeightEntry) -> Unit
) : ListAdapter<WeightEntry, WeightEntryAdapter.WeightEntryViewHolder>(WeightEntryDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightEntryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weight_entry, parent, false)
        return WeightEntryViewHolder(view)
    }

    override fun onBindViewHolder(holder: WeightEntryViewHolder, position: Int) {
        holder.bind(getItem(position), onDeleteClick)
    }

    class WeightEntryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvWeight: TextView = itemView.findViewById(R.id.tvWeight)
        private val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)

        fun bind(entry: WeightEntry, onDeleteClick: (WeightEntry) -> Unit) {
            tvWeight.text = String.format(Locale.getDefault(), "%.1f lbs", entry.weight)

            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            tvDate.text = dateFormat.format(Date(entry.timestamp))

            btnDelete.setOnClickListener {
                onDeleteClick(entry)
            }
        }
    }

    /**
     * DiffUtil callback for efficient list updates.
     */
    class WeightEntryDiffCallback : DiffUtil.ItemCallback<WeightEntry>() {
        override fun areItemsTheSame(oldItem: WeightEntry, newItem: WeightEntry): Boolean {
            return oldItem.entryId == newItem.entryId
        }

        override fun areContentsTheSame(oldItem: WeightEntry, newItem: WeightEntry): Boolean {
            return oldItem == newItem
        }
    }
}