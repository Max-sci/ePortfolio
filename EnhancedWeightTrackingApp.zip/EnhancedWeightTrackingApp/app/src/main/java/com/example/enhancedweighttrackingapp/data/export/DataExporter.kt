package com.example.weight_trackingapp.data.export

import android.content.Context
import android.net.Uri
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.data.local.entity.GoalWeight
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * DataExporter - Handles exporting weight data to various formats.
 *
 * SUPPORTED FORMATS:
 * - CSV: Human-readable, spreadsheet compatible
 * - JSON: Full backup with metadata
 *
 * COURSE OUTCOME 4: Demonstrate ability to use well-founded techniques
 * for implementing database solutions that deliver value.
 */
class DataExporter(private val context: Context) {

    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timestampFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    /**
     * Exports weight entries to CSV format.
     *
     * CSV FORMAT:
     * Date,Weight (lbs),Timestamp
     * 2024-01-15,185.5,1705312800000
     *
     * @param entries List of weight entries to export
     * @param uri Destination URI for the file
     * @return Result indicating success or failure
     */
    fun exportToCsv(entries: List<WeightEntry>, uri: Uri): ExportResult {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    // Write CSV header
                    writer.write("Date,Weight (lbs),Timestamp\n")

                    // Write each entry
                    for (entry in entries.sortedBy { it.timestamp }) {
                        val date = dateFormatter.format(Date(entry.timestamp))
                        val weight = String.format(Locale.US, "%.1f", entry.weight)
                        val timestamp = entry.timestamp.toString()

                        writer.write("$date,$weight,$timestamp\n")
                    }
                }
            }
            ExportResult.Success(entries.size, "CSV")
        } catch (e: Exception) {
            ExportResult.Error("Failed to export CSV: ${e.message}")
        }
    }

    /**
     * Exports complete backup to JSON format.
     *
     * Includes:
     * - Weight entries
     * - Goal weight
     * - Export metadata (date, version, count)
     *
     * @param entries List of weight entries
     * @param goalWeight Current goal weight (optional)
     * @param uri Destination URI
     * @return Result indicating success or failure
     */
    fun exportToJson(
        entries: List<WeightEntry>,
        goalWeight: GoalWeight?,
        uri: Uri
    ): ExportResult {
        return try {
            val jsonObject = JSONObject().apply {
                // Metadata
                put("exportDate", timestampFormatter.format(Date()))
                put("version", 1)
                put("entryCount", entries.size)

                // Goal weight
                goalWeight?.let {
                    put("goalWeight", JSONObject().apply {
                        put("weight", it.goalWeight)
                        put("startingWeight", it.startingWeight)
                        put("setDate", it.createdAt)
                    })
                }

                // Weight entries
                val entriesArray = JSONArray()
                for (entry in entries.sortedBy { it.timestamp }) {
                    entriesArray.put(JSONObject().apply {
                        put("weight", entry.weight)
                        put("timestamp", entry.timestamp)
                        put("date", dateFormatter.format(Date(entry.timestamp)))
                    })
                }
                put("weightEntries", entriesArray)
            }

            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    writer.write(jsonObject.toString(2)) // Pretty print with indent
                }
            }

            ExportResult.Success(entries.size, "JSON")
        } catch (e: Exception) {
            ExportResult.Error("Failed to export JSON: ${e.message}")
        }
    }

    /**
     * Generates a suggested filename based on current date.
     */
    fun generateFilename(format: String): String {
        val date = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        return when (format.lowercase()) {
            "csv" -> "weight_data_$date.csv"
            "json" -> "weight_backup_$date.json"
            else -> "weight_export_$date.txt"
        }
    }

    /**
     * Result class for export operations.
     */
    sealed class ExportResult {
        data class Success(val count: Int, val format: String) : ExportResult()
        data class Error(val message: String) : ExportResult()
    }
}