package com.example.weight_trackingapp.data.remote

import retrofit2.Response
import retrofit2.http.*

/**
 * API Service Interface
 *
 * Defines all REST API endpoints for the Weight Tracker backend
 * Uses Retrofit annotations for HTTP methods
 *
 * COURSE OUTCOME: RESTful API Backend integration
 */
interface ApiService {

    // ==================== AUTH ENDPOINTS ====================

    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>

    // ==================== WEIGHT ENTRIES ENDPOINTS ====================

    @GET("api/weights")
    suspend fun getWeightEntries(@Header("Authorization") token: String): Response<List<WeightEntryResponse>>

    @POST("api/weights")
    suspend fun createWeightEntry(
        @Header("Authorization") token: String,
        @Body request: WeightEntryRequest
    ): Response<WeightEntryResponse>

    @DELETE("api/weights/{id}")
    suspend fun deleteWeightEntry(
        @Header("Authorization") token: String,
        @Path("id") entryId: String
    ): Response<DeleteResponse>

    @POST("api/weights/sync")
    suspend fun syncWeightEntries(
        @Header("Authorization") token: String,
        @Body request: SyncRequest
    ): Response<SyncResponse>

    // ==================== GOAL ENDPOINTS ====================

    @GET("api/weights/goal/current")
    suspend fun getGoal(@Header("Authorization") token: String): Response<GoalResponse>

    @POST("api/weights/goal")
    suspend fun setGoal(
        @Header("Authorization") token: String,
        @Body request: GoalRequest
    ): Response<GoalResponse>

    // ==================== STATS ENDPOINTS ====================

    @GET("api/stats/summary")
    suspend fun getStatsSummary(@Header("Authorization") token: String): Response<StatsSummaryResponse>

    @GET("api/stats/weekly")
    suspend fun getWeeklyStats(@Header("Authorization") token: String): Response<List<WeeklyStatsResponse>>

    @GET("api/stats/monthly")
    suspend fun getMonthlyStats(@Header("Authorization") token: String): Response<List<MonthlyStatsResponse>>

    @GET("api/stats/trend")
    suspend fun getTrend(@Header("Authorization") token: String): Response<TrendResponse>
}