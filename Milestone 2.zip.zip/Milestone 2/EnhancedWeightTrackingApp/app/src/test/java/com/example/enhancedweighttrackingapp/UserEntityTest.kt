package com.example.weight_trackingapp

import com.example.weight_trackingapp.data.local.entity.User
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for User entity.
 *
 * Tests user creation and constants.
 */
class UserEntityTest {

    @Test
    fun user_defaultValuesAreCorrect() {
        val user = User(
            username = "testuser",
            passwordHash = "hashedpassword"
        )

        assertEquals(0, user.userId)
        assertEquals("testuser", user.username)
        assertEquals("hashedpassword", user.passwordHash)
        assertEquals(0, user.failedLoginAttempts)
        assertFalse(user.isLocked)
    }

    @Test
    fun user_maxFailedAttemptsIsFive() {
        assertEquals(5, User.MAX_FAILED_ATTEMPTS)
    }

    @Test
    fun user_createdAtIsSet() {
        val beforeCreation = System.currentTimeMillis()
        val user = User(
            username = "testuser",
            passwordHash = "hashedpassword"
        )
        val afterCreation = System.currentTimeMillis()

        assertTrue(user.createdAt >= beforeCreation)
        assertTrue(user.createdAt <= afterCreation)
    }

    @Test
    fun user_canBeCreatedWithCustomValues() {
        val user = User(
            userId = 10,
            username = "customuser",
            passwordHash = "customhash",
            failedLoginAttempts = 3,
            isLocked = true
        )

        assertEquals(10, user.userId)
        assertEquals("customuser", user.username)
        assertEquals("customhash", user.passwordHash)
        assertEquals(3, user.failedLoginAttempts)
        assertTrue(user.isLocked)
    }
}