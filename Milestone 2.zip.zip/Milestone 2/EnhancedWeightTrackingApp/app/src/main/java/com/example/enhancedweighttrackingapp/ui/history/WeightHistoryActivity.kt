package com.example.weight_trackingapp.ui.history

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weight_trackingapp.R
import com.example.weight_trackingapp.data.local.AppDatabase
import com.example.weight_trackingapp.data.local.entity.WeightEntry
import com.example.weight_trackingapp.data.repository.WeightRepository
import com.example.weight_trackingapp.util.SecureSessionManager
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Weight History Activity - Log and view weight entries.
 */
class WeightHistoryActivity : AppCompatActivity() {

    private lateinit var sessionManager: SecureSessionManager

    // Views
    private lateinit var toolbar: MaterialToolbar
    private lateinit var etWeight: TextInputEditText
    private lateinit var etDate: TextInputEditText
    private lateinit var btnAddEntry: MaterialButton
    private lateinit var rvWeightEntries: RecyclerView
    private lateinit var layoutEmptyState: LinearLayout

    private lateinit var adapter: WeightEntryAdapter
    private val selectedDate = Calendar.getInstance()

    // ViewModel
    private val viewModel: WeightHistoryViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        val repository = WeightRepository(
            database.userDao(),
            database.weightEntryDao(),
            database.goalWeightDao()
        )
        WeightHistoryViewModelFactory(repository, sessionManager.getUserId())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_history)

        sessionManager = SecureSessionManager(this)

        initializeViews()
        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        observeViewModel()

        updateDateField()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        etWeight = findViewById(R.id.etWeight)
        etDate = findViewById(R.id.etDate)
        btnAddEntry = findViewById(R.id.btnAddEntry)
        rvWeightEntries = findViewById(R.id.rvWeightEntries)
        layoutEmptyState = findViewById(R.id.layoutEmptyState)
    }

    private fun setupToolbar() {
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        adapter = WeightEntryAdapter { entry ->
            showDeleteDialog(entry)
        }
        rvWeightEntries.layoutManager = LinearLayoutManager(this)
        rvWeightEntries.adapter = adapter
    }

    private fun setupClickListeners() {
        etDate.setOnClickListener {
            showDatePicker()
        }

        btnAddEntry.setOnClickListener {
            val weight = etWeight.text.toString()
            viewModel.addWeightEntry(weight)
        }
    }

    private fun observeViewModel() {
        // Observe weight entries
        viewModel.weightEntries.observe(this) { entries ->
            if (entries.isEmpty()) {
                rvWeightEntries.visibility = View.GONE
                layoutEmptyState.visibility = View.VISIBLE
            } else {
                rvWeightEntries.visibility = View.VISIBLE
                layoutEmptyState.visibility = View.GONE
                adapter.submitList(entries)
            }
        }

        // Observe add entry result
        viewModel.addEntryResult.observe(this) { result ->
            when (result) {
                is WeightHistoryViewModel.AddEntryResult.Success -> {
                    Toast.makeText(this, "Weight entry added!", Toast.LENGTH_SHORT).show()
                    etWeight.setText("")
                    viewModel.clearAddEntryResult()
                }
                is WeightHistoryViewModel.AddEntryResult.Error -> {
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    viewModel.clearAddEntryResult()
                }
                null -> { /* Do nothing */ }
            }
        }
    }

    private fun showDatePicker() {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate.set(year, month, dayOfMonth)
                updateDateField()
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateDateField() {
        val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
        etDate.setText(dateFormat.format(selectedDate.time))
    }

    private fun showDeleteDialog(entry: WeightEntry) {
        AlertDialog.Builder(this)
            .setTitle("Delete Entry")
            .setMessage("Are you sure you want to delete this entry?")
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteWeightEntry(entry)
                Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}