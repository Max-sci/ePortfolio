package com.example.weight_trackingapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.weight_trackingapp.data.local.entity.User
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for User operations.
 *
 * DESIGN IMPROVEMENTS:
 * - Suspend functions for non-blocking database calls
 * - Flow for reactive data observation
 * - Security queries for login attempt tracking
 */
@Dao
interface UserDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: User): Long

    @Update
    suspend fun updateUser(user: User)

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): User?

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: Int): User?

    @Query("SELECT COUNT(*) FROM users WHERE username = :username")
    suspend fun checkUserExists(username: String): Int

    @Query("UPDATE users SET failedLoginAttempts = :attempts WHERE userId = :userId")
    suspend fun updateFailedAttempts(userId: Int, attempts: Int)

    @Query("UPDATE users SET isLocked = :locked WHERE userId = :userId")
    suspend fun setAccountLocked(userId: Int, locked: Boolean)

    @Query("SELECT * FROM users WHERE userId = :userId")
    fun observeUser(userId: Int): Flow<User?>
}