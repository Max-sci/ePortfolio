package com.example.weight_trackingapp.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * GoalWeight Entity - Represents a user's weight loss goal.
 *
 * DESIGN IMPROVEMENTS:
 * - Tracks starting weight for accurate progress calculation
 * - Records when goal was created and achieved
 * - Supports goal completion tracking
 */
@Entity(
    tableName = "goal_weights",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"], unique = true)]
)
data class GoalWeight(
    @PrimaryKey(autoGenerate = true)
    val goalId: Int = 0,

    val userId: Int,

    val goalWeight: Double,

    val startingWeight: Double,

    val createdAt: Long = System.currentTimeMillis(),

    val isAchieved: Boolean = false,

    val achievedAt: Long? = null
) {
    /**
     * Calculates progress percentage based on current weight.
     */
    fun calculateProgress(currentWeight: Double): Int {
        val totalToLose = startingWeight - goalWeight
        if (totalToLose <= 0) return 100

        val lost = startingWeight - currentWeight
        val progress = (lost / totalToLose * 100).toInt()
        return progress.coerceIn(0, 100)
    }

    /**
     * Calculates remaining weight to goal.
     */
    fun remainingWeight(currentWeight: Double): Double {
        return currentWeight - goalWeight
    }
}