package com.example.weight_trackingapp.util

import at.favre.lib.crypto.bcrypt.BCrypt

/**
 * Security Utilities for password hashing and validation.
 *
 * SECURITY FEATURES:
 * - BCrypt hashing (industry standard)
 * - Automatic salt generation
 * - Timing-safe password comparison
 * - Input validation
 */
object SecurityUtils {

    // BCrypt cost factor (higher = more secure but slower)
    private const val BCRYPT_COST = 12

    // Validation constants
    const val MIN_PASSWORD_LENGTH = 8
    const val MIN_USERNAME_LENGTH = 3
    const val MAX_USERNAME_LENGTH = 50

    /**
     * Hashes a password using BCrypt.
     * Salt is automatically generated and included in the hash.
     */
    fun hashPassword(password: String): String {
        return BCrypt.withDefaults().hashToString(BCRYPT_COST, password.toCharArray())
    }

    /**
     * Verifies a password against a BCrypt hash.
     * Uses constant-time comparison to prevent timing attacks.
     */
    fun verifyPassword(password: String, hash: String): Boolean {
        return try {
            BCrypt.verifyer().verify(password.toCharArray(), hash).verified
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Validates password meets security requirements.
     */
    fun validatePassword(password: String): ValidationResult {
        return when {
            password.length < MIN_PASSWORD_LENGTH ->
                ValidationResult(false, "Password must be at least $MIN_PASSWORD_LENGTH characters")
            !password.any { it.isUpperCase() } ->
                ValidationResult(false, "Password must contain an uppercase letter")
            !password.any { it.isLowerCase() } ->
                ValidationResult(false, "Password must contain a lowercase letter")
            !password.any { it.isDigit() } ->
                ValidationResult(false, "Password must contain a number")
            else -> ValidationResult(true, "")
        }
    }

    /**
     * Validates username meets requirements.
     */
    fun validateUsername(username: String): ValidationResult {
        return when {
            username.length < MIN_USERNAME_LENGTH ->
                ValidationResult(false, "Username must be at least $MIN_USERNAME_LENGTH characters")
            username.length > MAX_USERNAME_LENGTH ->
                ValidationResult(false, "Username must be less than $MAX_USERNAME_LENGTH characters")
            !username.matches(Regex("^[a-zA-Z][a-zA-Z0-9_]*$")) ->
                ValidationResult(false, "Username must start with a letter and contain only letters, numbers, and underscores")
            else -> ValidationResult(true, "")
        }
    }

    /**
     * Sanitizes user input.
     */
    fun sanitizeInput(input: String): String {
        return input.trim().take(1000)
    }

    /**
     * Result of a validation operation.
     */
    data class ValidationResult(
        val isValid: Boolean,
        val errorMessage: String
    )
}