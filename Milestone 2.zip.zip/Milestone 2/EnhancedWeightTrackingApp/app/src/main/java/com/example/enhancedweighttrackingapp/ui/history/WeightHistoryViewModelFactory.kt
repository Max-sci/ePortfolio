package com.example.weight_trackingapp.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.weight_trackingapp.data.repository.WeightRepository

/**
 * Factory for creating WeightHistoryViewModel with dependencies.
 */
class WeightHistoryViewModelFactory(
    private val repository: WeightRepository,
    private val userId: Int
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WeightHistoryViewModel::class.java)) {
            return WeightHistoryViewModel(repository, userId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}